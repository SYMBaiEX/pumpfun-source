"""Observe TCP/UDP loopback denial directly and through a child process."""
import errno
import hashlib
import json
from pathlib import Path
import socket
import subprocess
import sys
import time

GUARD = '/usr/bin/sandbox-exec'
PIN = '0c39f18a1a71e2c31cc9a07deac4418a1701454718df98caa812705f84520e3e'
PROFILE = '(version 1)(allow default)(deny network*)'
PROBE = '''import json, socket, sys
try:
    with socket.socket(socket.AF_INET, int(sys.argv[1])) as client:
        client.settimeout(2)
        client.connect(('127.0.0.1', int(sys.argv[2])))
        client.send(b'collector-guard-control')
    print(json.dumps({'sent': True}))
except OSError as error:
    print(json.dumps({'sent': False, 'errno': error.errno, 'error': str(error)}))
'''
DESCENDANT = 'import subprocess,sys; sys.exit(subprocess.call(sys.argv[1:]))'


def run(output):
    actual = hashlib.sha256(Path(GUARD).read_bytes()).hexdigest()
    assert actual == PIN
    result = {'status': 'RUNNING', 'started_unix': time.time(), 'guard_sha256': actual,
              'profile': PROFILE, 'observations': [], 'scope': 'Loopback TCP/UDP only; no external network requests.'}
    for kind in (socket.SOCK_STREAM, socket.SOCK_DGRAM):
        with socket.socket(socket.AF_INET, kind) as server:
            server.bind(('127.0.0.1', 0))
            server.settimeout(0.2)
            if kind == socket.SOCK_STREAM:
                server.listen()
            port = server.getsockname()[1]
            for descendant in (False, True):
                for guarded in (False, True):
                    command = [sys.executable, '-B', '-c', PROBE, str(int(kind)), str(port)]
                    if descendant:
                        command = [sys.executable, '-B', '-c', DESCENDANT, *command]
                    if guarded:
                        command = [GUARD, '-p', PROFILE, *command]
                    child = subprocess.run(command, capture_output=True, text=True, timeout=15)
                    assert child.returncode == 0, child.stderr
                    observed = json.loads(child.stdout)
                    received = None
                    try:
                        if kind == socket.SOCK_STREAM:
                            connection, _ = server.accept()
                            with connection:
                                connection.settimeout(1)
                                received = connection.recv(1024).decode()
                        else:
                            received = server.recv(1024).decode()
                    except socket.timeout:
                        pass
                    row = {'transport': 'TCP' if kind == socket.SOCK_STREAM else 'UDP',
                           'descendant': descendant, 'guarded': guarded, 'command': command,
                           'returncode': child.returncode, 'stderr': child.stderr,
                           'probe': observed, 'server_received': received}
                    result['observations'].append(row)
                    if guarded:
                        assert observed.get('sent') is False and observed.get('errno') in (errno.EPERM, errno.EACCES)
                        assert received is None
                    else:
                        assert observed == {'sent': True} and received == 'collector-guard-control'
    assert hashlib.sha256(Path(GUARD).read_bytes()).hexdigest() == actual
    result.update(status='PASS', finished_unix=time.time(), controls_allowed=4, guarded_attempts_denied=4)
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('status', 'controls_allowed', 'guarded_attempts_denied')}))


if __name__ == '__main__':
    run(Path(__file__).with_name('guard-probe.json'))
