
/Users/symbiex/dev/austin/lalalune/mayhem-initializer-recovery-20261026/vault-reuse/build/target/sbf-solana-solana/release/mayhem_recovered.so:	file format elf64-sbf

Disassembly of section .text:

0000000000065428 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E>:
   65428: bf 29 00 00 00 00 00 00      	mov64 r9, r2
   65430: bf 18 00 00 00 00 00 00      	mov64 r8, r1
   65438: 79 96 00 00 00 00 00 00      	ldxdw r6, [r9 + 0x0]
   65440: 79 62 00 00 00 00 00 00      	ldxdw r2, [r6 + 0x0]
   65448: 79 27 18 00 00 00 00 00      	ldxdw r7, [r2 + 0x18]
   65450: 79 71 00 00 00 00 00 00      	ldxdw r1, [r7 + 0x0]
   65458: 55 01 06 00 00 00 00 00      	jne r1, 0x0, +0x6 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x68>
   65460: 79 71 08 00 00 00 00 00      	ldxdw r1, [r7 + 0x8]
   65468: 55 01 04 00 00 00 00 00      	jne r1, 0x0, +0x4 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x68>
   65470: 79 71 10 00 00 00 00 00      	ldxdw r1, [r7 + 0x10]
   65478: 55 01 02 00 00 00 00 00      	jne r1, 0x0, +0x2 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x68>
   65480: 79 71 18 00 00 00 00 00      	ldxdw r1, [r7 + 0x18]
   65488: 15 01 2e 03 00 00 00 00      	jeq r1, 0x0, +0x32e <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x19d8>
   65490: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   65498: 55 01 39 01 00 00 00 00      	jne r1, 0x0, +0x139 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xa40>
   654a0: 79 91 08 00 00 00 00 00      	ldxdw r1, [r9 + 0x8]
   654a8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   654b0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   654b8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   654c0: 7b 2a 58 ff 00 00 00 00      	stxdw [r10 - 0xa8], r2
   654c8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   654d0: 7b 2a 50 ff 00 00 00 00      	stxdw [r10 - 0xb0], r2
   654d8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   654e0: 7b 2a 48 ff 00 00 00 00      	stxdw [r10 - 0xb8], r2
   654e8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   654f0: 7b 1a 40 ff 00 00 00 00      	stxdw [r10 - 0xc0], r1
   654f8: 79 91 10 00 00 00 00 00      	ldxdw r1, [r9 + 0x10]
   65500: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   65508: 79 20 08 00 00 00 00 00      	ldxdw r0, [r2 + 0x8]
   65510: 79 01 00 00 00 00 00 00      	ldxdw r1, [r0 + 0x0]
   65518: 07 01 00 00 01 00 00 00      	add64 r1, 0x1
   65520: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
   65528: 15 01 01 00 00 00 00 00      	jeq r1, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x110>
   65530: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   65538: 79 25 00 00 00 00 00 00      	ldxdw r5, [r2 + 0x0]
   65540: 7b 10 00 00 00 00 00 00      	stxdw [r0 + 0x0], r1
   65548: 15 03 1f 03 01 00 00 00      	jeq r3, 0x1, +0x31f <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1a20>
   65550: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   65558: 79 41 00 00 00 00 00 00      	ldxdw r1, [r4 + 0x0]
   65560: 07 01 00 00 01 00 00 00      	add64 r1, 0x1
   65568: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
   65570: 15 01 01 00 00 00 00 00      	jeq r1, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x158>
   65578: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   65580: 7b 14 00 00 00 00 00 00      	stxdw [r4 + 0x0], r1
   65588: 15 03 17 03 01 00 00 00      	jeq r3, 0x1, +0x317 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1a20>
   65590: 7b 5a 08 fc 00 00 00 00      	stxdw [r10 - 0x3f8], r5
   65598: 7b 4a 00 fc 00 00 00 00      	stxdw [r10 - 0x400], r4
   655a0: 79 61 00 00 00 00 00 00      	ldxdw r1, [r6 + 0x0]
   655a8: 79 13 08 00 00 00 00 00      	ldxdw r3, [r1 + 0x8]
   655b0: 7b 3a 20 fc 00 00 00 00      	stxdw [r10 - 0x3e0], r3
   655b8: 79 33 00 00 00 00 00 00      	ldxdw r3, [r3 + 0x0]
   655c0: 07 03 00 00 01 00 00 00      	add64 r3, 0x1
   655c8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   655d0: 15 03 01 00 00 00 00 00      	jeq r3, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1b8>
   655d8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   655e0: 71 25 2a 00 00 00 00 00      	ldxb r5, [r2 + 0x2a]
   655e8: 7b 5a d8 fb 00 00 00 00      	stxdw [r10 - 0x428], r5
   655f0: 71 25 29 00 00 00 00 00      	ldxb r5, [r2 + 0x29]
   655f8: 7b 5a e0 fb 00 00 00 00      	stxdw [r10 - 0x420], r5
   65600: 71 25 28 00 00 00 00 00      	ldxb r5, [r2 + 0x28]
   65608: 7b 5a e8 fb 00 00 00 00      	stxdw [r10 - 0x418], r5
   65610: 79 25 20 00 00 00 00 00      	ldxdw r5, [r2 + 0x20]
   65618: 7b 5a f0 fb 00 00 00 00      	stxdw [r10 - 0x410], r5
   65620: 79 22 18 00 00 00 00 00      	ldxdw r2, [r2 + 0x18]
   65628: 7b 2a f8 fb 00 00 00 00      	stxdw [r10 - 0x408], r2
   65630: 79 15 00 00 00 00 00 00      	ldxdw r5, [r1 + 0x0]
   65638: 79 a2 20 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3e0]
   65640: 7b 32 00 00 00 00 00 00      	stxdw [r2 + 0x0], r3
   65648: 15 04 ff 02 01 00 00 00      	jeq r4, 0x1, +0x2ff <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1a20>
   65650: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   65658: 79 42 00 00 00 00 00 00      	ldxdw r2, [r4 + 0x0]
   65660: 07 02 00 00 01 00 00 00      	add64 r2, 0x1
   65668: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
   65670: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x258>
   65678: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   65680: 7b 24 00 00 00 00 00 00      	stxdw [r4 + 0x0], r2
   65688: 15 03 f7 02 01 00 00 00      	jeq r3, 0x1, +0x2f7 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1a20>
   65690: 7b 5a d0 fb 00 00 00 00      	stxdw [r10 - 0x430], r5
   65698: 7b 4a c8 fb 00 00 00 00      	stxdw [r10 - 0x438], r4
   656a0: 79 92 18 00 00 00 00 00      	ldxdw r2, [r9 + 0x18]
   656a8: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   656b0: 79 32 08 00 00 00 00 00      	ldxdw r2, [r3 + 0x8]
   656b8: 7b 2a 18 fc 00 00 00 00      	stxdw [r10 - 0x3e8], r2
   656c0: 79 22 00 00 00 00 00 00      	ldxdw r2, [r2 + 0x0]
   656c8: 07 02 00 00 01 00 00 00      	add64 r2, 0x1
   656d0: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   656d8: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x2c0>
   656e0: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   656e8: 71 15 2a 00 00 00 00 00      	ldxb r5, [r1 + 0x2a]
   656f0: 7b 5a a0 fb 00 00 00 00      	stxdw [r10 - 0x460], r5
   656f8: 71 15 29 00 00 00 00 00      	ldxb r5, [r1 + 0x29]
   65700: 7b 5a a8 fb 00 00 00 00      	stxdw [r10 - 0x458], r5
   65708: 71 15 28 00 00 00 00 00      	ldxb r5, [r1 + 0x28]
   65710: 7b 5a b0 fb 00 00 00 00      	stxdw [r10 - 0x450], r5
   65718: 79 15 20 00 00 00 00 00      	ldxdw r5, [r1 + 0x20]
   65720: 7b 5a b8 fb 00 00 00 00      	stxdw [r10 - 0x448], r5
   65728: 79 11 18 00 00 00 00 00      	ldxdw r1, [r1 + 0x18]
   65730: 7b 1a c0 fb 00 00 00 00      	stxdw [r10 - 0x440], r1
   65738: 79 35 00 00 00 00 00 00      	ldxdw r5, [r3 + 0x0]
   65740: 79 a1 18 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e8]
   65748: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   65750: 15 04 de 02 01 00 00 00      	jeq r4, 0x1, +0x2de <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1a20>
   65758: 79 34 10 00 00 00 00 00      	ldxdw r4, [r3 + 0x10]
   65760: 79 41 00 00 00 00 00 00      	ldxdw r1, [r4 + 0x0]
   65768: 07 01 00 00 01 00 00 00      	add64 r1, 0x1
   65770: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   65778: 15 01 01 00 00 00 00 00      	jeq r1, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x360>
   65780: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   65788: 7b 14 00 00 00 00 00 00      	stxdw [r4 + 0x0], r1
   65790: 15 02 d6 02 01 00 00 00      	jeq r2, 0x1, +0x2d6 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1a20>
   65798: 7b 8a 28 fc 00 00 00 00      	stxdw [r10 - 0x3d8], r8
   657a0: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   657a8: bf 70 00 00 00 00 00 00      	mov64 r0, r7
   657b0: 7b 4a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r4
   657b8: 79 91 20 00 00 00 00 00      	ldxdw r1, [r9 + 0x20]
   657c0: 79 14 58 00 00 00 00 00      	ldxdw r4, [r1 + 0x58]
   657c8: 79 41 08 00 00 00 00 00      	ldxdw r1, [r4 + 0x8]
   657d0: 7b 1a 10 fc 00 00 00 00      	stxdw [r10 - 0x3f0], r1
   657d8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   657e0: 07 01 00 00 01 00 00 00      	add64 r1, 0x1
   657e8: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   657f0: 15 01 01 00 00 00 00 00      	jeq r1, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x3d8>
   657f8: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   65800: 71 37 2a 00 00 00 00 00      	ldxb r7, [r3 + 0x2a]
   65808: 7b 7a 70 fb 00 00 00 00      	stxdw [r10 - 0x490], r7
   65810: 71 37 29 00 00 00 00 00      	ldxb r7, [r3 + 0x29]
   65818: 7b 7a 78 fb 00 00 00 00      	stxdw [r10 - 0x488], r7
   65820: 71 37 28 00 00 00 00 00      	ldxb r7, [r3 + 0x28]
   65828: 7b 7a 80 fb 00 00 00 00      	stxdw [r10 - 0x480], r7
   65830: 79 37 20 00 00 00 00 00      	ldxdw r7, [r3 + 0x20]
   65838: 7b 7a 88 fb 00 00 00 00      	stxdw [r10 - 0x478], r7
   65840: 79 33 18 00 00 00 00 00      	ldxdw r3, [r3 + 0x18]
   65848: 7b 3a 90 fb 00 00 00 00      	stxdw [r10 - 0x470], r3
   65850: 79 47 00 00 00 00 00 00      	ldxdw r7, [r4 + 0x0]
   65858: 79 a3 10 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3f0]
   65860: 7b 13 00 00 00 00 00 00      	stxdw [r3 + 0x0], r1
   65868: 15 02 bb 02 01 00 00 00      	jeq r2, 0x1, +0x2bb <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1a20>
   65870: 7b 7a 68 fb 00 00 00 00      	stxdw [r10 - 0x498], r7
   65878: 79 43 10 00 00 00 00 00      	ldxdw r3, [r4 + 0x10]
   65880: 79 31 00 00 00 00 00 00      	ldxdw r1, [r3 + 0x0]
   65888: 07 01 00 00 01 00 00 00      	add64 r1, 0x1
   65890: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   65898: 15 01 01 00 00 00 00 00      	jeq r1, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x480>
   658a0: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   658a8: 7b 13 00 00 00 00 00 00      	stxdw [r3 + 0x0], r1
   658b0: bf 07 00 00 00 00 00 00      	mov64 r7, r0
   658b8: 15 02 b1 02 01 00 00 00      	jeq r2, 0x1, +0x2b1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1a20>
   658c0: 7b 3a 58 fb 00 00 00 00      	stxdw [r10 - 0x4a8], r3
   658c8: 7b 5a 60 fb 00 00 00 00      	stxdw [r10 - 0x4a0], r5
   658d0: 79 91 28 00 00 00 00 00      	ldxdw r1, [r9 + 0x28]
   658d8: 79 15 00 00 00 00 00 00      	ldxdw r5, [r1 + 0x0]
   658e0: 79 51 08 00 00 00 00 00      	ldxdw r1, [r5 + 0x8]
   658e8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   658f0: 07 02 00 00 01 00 00 00      	add64 r2, 0x1
   658f8: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
   65900: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x4e8>
   65908: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   65910: 71 40 2a 00 00 00 00 00      	ldxb r0, [r4 + 0x2a]
   65918: 7b 0a 38 fb 00 00 00 00      	stxdw [r10 - 0x4c8], r0
   65920: 71 40 29 00 00 00 00 00      	ldxb r0, [r4 + 0x29]
   65928: 7b 0a 40 fb 00 00 00 00      	stxdw [r10 - 0x4c0], r0
   65930: 71 40 28 00 00 00 00 00      	ldxb r0, [r4 + 0x28]
   65938: 7b 0a 48 fb 00 00 00 00      	stxdw [r10 - 0x4b8], r0
   65940: 79 40 20 00 00 00 00 00      	ldxdw r0, [r4 + 0x20]
   65948: 7b 0a 50 fb 00 00 00 00      	stxdw [r10 - 0x4b0], r0
   65950: 79 40 18 00 00 00 00 00      	ldxdw r0, [r4 + 0x18]
   65958: 79 54 00 00 00 00 00 00      	ldxdw r4, [r5 + 0x0]
   65960: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   65968: 15 03 9b 02 01 00 00 00      	jeq r3, 0x1, +0x29b <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1a20>
   65970: 7b 4a 30 fb 00 00 00 00      	stxdw [r10 - 0x4d0], r4
   65978: 79 54 10 00 00 00 00 00      	ldxdw r4, [r5 + 0x10]
   65980: 79 42 00 00 00 00 00 00      	ldxdw r2, [r4 + 0x0]
   65988: 07 02 00 00 01 00 00 00      	add64 r2, 0x1
   65990: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
   65998: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x580>
   659a0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   659a8: 7b 24 00 00 00 00 00 00      	stxdw [r4 + 0x0], r2
   659b0: 15 03 92 02 01 00 00 00      	jeq r3, 0x1, +0x292 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1a20>
   659b8: 7b 1a 18 fb 00 00 00 00      	stxdw [r10 - 0x4e8], r1
   659c0: 7b 0a 20 fb 00 00 00 00      	stxdw [r10 - 0x4e0], r0
   659c8: 7b 8a 28 fb 00 00 00 00      	stxdw [r10 - 0x4d8], r8
   659d0: 7b 9a f0 fa 00 00 00 00      	stxdw [r10 - 0x510], r9
   659d8: 79 92 30 00 00 00 00 00      	ldxdw r2, [r9 + 0x30]
   659e0: 79 20 00 00 00 00 00 00      	ldxdw r0, [r2 + 0x0]
   659e8: 79 08 08 00 00 00 00 00      	ldxdw r8, [r0 + 0x8]
   659f0: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   659f8: 07 02 00 00 01 00 00 00      	add64 r2, 0x1
   65a00: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
   65a08: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x5f0>
   65a10: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   65a18: 71 51 2a 00 00 00 00 00      	ldxb r1, [r5 + 0x2a]
   65a20: 7b 1a f8 fa 00 00 00 00      	stxdw [r10 - 0x508], r1
   65a28: 71 51 29 00 00 00 00 00      	ldxb r1, [r5 + 0x29]
   65a30: 7b 1a 00 fb 00 00 00 00      	stxdw [r10 - 0x500], r1
   65a38: 71 51 28 00 00 00 00 00      	ldxb r1, [r5 + 0x28]
   65a40: 7b 1a 08 fb 00 00 00 00      	stxdw [r10 - 0x4f8], r1
   65a48: 79 51 20 00 00 00 00 00      	ldxdw r1, [r5 + 0x20]
   65a50: 7b 1a 10 fb 00 00 00 00      	stxdw [r10 - 0x4f0], r1
   65a58: 79 51 18 00 00 00 00 00      	ldxdw r1, [r5 + 0x18]
   65a60: 79 09 00 00 00 00 00 00      	ldxdw r9, [r0 + 0x0]
   65a68: 7b 28 00 00 00 00 00 00      	stxdw [r8 + 0x0], r2
   65a70: 15 03 7a 02 01 00 00 00      	jeq r3, 0x1, +0x27a <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1a20>
   65a78: 79 02 10 00 00 00 00 00      	ldxdw r2, [r0 + 0x10]
   65a80: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   65a88: 07 03 00 00 01 00 00 00      	add64 r3, 0x1
   65a90: b7 05 00 00 01 00 00 00      	mov64 r5, 0x1
   65a98: 15 03 01 00 00 00 00 00      	jeq r3, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x680>
   65aa0: b7 05 00 00 00 00 00 00      	mov64 r5, 0x0
   65aa8: 7b 32 00 00 00 00 00 00      	stxdw [r2 + 0x0], r3
   65ab0: 15 05 72 02 01 00 00 00      	jeq r5, 0x1, +0x272 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1a20>
   65ab8: 7b 6a e0 fa 00 00 00 00      	stxdw [r10 - 0x520], r6
   65ac0: 7b 7a e8 fa 00 00 00 00      	stxdw [r10 - 0x518], r7
   65ac8: 79 03 18 00 00 00 00 00      	ldxdw r3, [r0 + 0x18]
   65ad0: 79 05 20 00 00 00 00 00      	ldxdw r5, [r0 + 0x20]
   65ad8: 71 06 28 00 00 00 00 00      	ldxb r6, [r0 + 0x28]
   65ae0: 71 07 29 00 00 00 00 00      	ldxb r7, [r0 + 0x29]
   65ae8: 71 00 2a 00 00 00 00 00      	ldxb r0, [r0 + 0x2a]
   65af0: 73 0a f2 fd 00 00 00 00      	stxb [r10 - 0x20e], r0
   65af8: 73 7a f1 fd 00 00 00 00      	stxb [r10 - 0x20f], r7
   65b00: 73 6a f0 fd 00 00 00 00      	stxb [r10 - 0x210], r6
   65b08: 7b 5a e8 fd 00 00 00 00      	stxdw [r10 - 0x218], r5
   65b10: 7b 3a e0 fd 00 00 00 00      	stxdw [r10 - 0x220], r3
   65b18: 7b 2a d8 fd 00 00 00 00      	stxdw [r10 - 0x228], r2
   65b20: 7b 8a d0 fd 00 00 00 00      	stxdw [r10 - 0x230], r8
   65b28: 7b 9a c8 fd 00 00 00 00      	stxdw [r10 - 0x238], r9
   65b30: 79 a2 f8 fa 00 00 00 00      	ldxdw r2, [r10 - 0x508]
   65b38: 73 2a c2 fd 00 00 00 00      	stxb [r10 - 0x23e], r2
   65b40: 79 a2 00 fb 00 00 00 00      	ldxdw r2, [r10 - 0x500]
   65b48: 73 2a c1 fd 00 00 00 00      	stxb [r10 - 0x23f], r2
   65b50: 79 a2 08 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4f8]
   65b58: 73 2a c0 fd 00 00 00 00      	stxb [r10 - 0x240], r2
   65b60: 79 a2 10 fb 00 00 00 00      	ldxdw r2, [r10 - 0x4f0]
   65b68: 7b 2a b8 fd 00 00 00 00      	stxdw [r10 - 0x248], r2
   65b70: 7b 1a b0 fd 00 00 00 00      	stxdw [r10 - 0x250], r1
   65b78: 7b 4a a8 fd 00 00 00 00      	stxdw [r10 - 0x258], r4
   65b80: 79 a1 18 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e8]
   65b88: 7b 1a a0 fd 00 00 00 00      	stxdw [r10 - 0x260], r1
   65b90: 79 a1 30 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4d0]
   65b98: 7b 1a 98 fd 00 00 00 00      	stxdw [r10 - 0x268], r1
   65ba0: 79 a1 38 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4c8]
   65ba8: 73 1a 92 fd 00 00 00 00      	stxb [r10 - 0x26e], r1
   65bb0: 79 a1 40 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4c0]
   65bb8: 73 1a 91 fd 00 00 00 00      	stxb [r10 - 0x26f], r1
   65bc0: 79 a1 48 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4b8]
   65bc8: 73 1a 90 fd 00 00 00 00      	stxb [r10 - 0x270], r1
   65bd0: 79 a1 50 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4b0]
   65bd8: 7b 1a 88 fd 00 00 00 00      	stxdw [r10 - 0x278], r1
   65be0: 79 a1 20 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4e0]
   65be8: 7b 1a 80 fd 00 00 00 00      	stxdw [r10 - 0x280], r1
   65bf0: 79 a1 58 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a8]
   65bf8: 7b 1a 78 fd 00 00 00 00      	stxdw [r10 - 0x288], r1
   65c00: 79 a1 10 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f0]
   65c08: 7b 1a 70 fd 00 00 00 00      	stxdw [r10 - 0x290], r1
   65c10: 79 a1 68 fb 00 00 00 00      	ldxdw r1, [r10 - 0x498]
   65c18: 7b 1a 68 fd 00 00 00 00      	stxdw [r10 - 0x298], r1
   65c20: 79 a1 70 fb 00 00 00 00      	ldxdw r1, [r10 - 0x490]
   65c28: 73 1a 62 fd 00 00 00 00      	stxb [r10 - 0x29e], r1
   65c30: 79 a1 78 fb 00 00 00 00      	ldxdw r1, [r10 - 0x488]
   65c38: 73 1a 61 fd 00 00 00 00      	stxb [r10 - 0x29f], r1
   65c40: 79 a1 80 fb 00 00 00 00      	ldxdw r1, [r10 - 0x480]
   65c48: 73 1a 60 fd 00 00 00 00      	stxb [r10 - 0x2a0], r1
   65c50: 79 a1 88 fb 00 00 00 00      	ldxdw r1, [r10 - 0x478]
   65c58: 7b 1a 58 fd 00 00 00 00      	stxdw [r10 - 0x2a8], r1
   65c60: 79 a1 90 fb 00 00 00 00      	ldxdw r1, [r10 - 0x470]
   65c68: 7b 1a 50 fd 00 00 00 00      	stxdw [r10 - 0x2b0], r1
   65c70: 79 a1 98 fb 00 00 00 00      	ldxdw r1, [r10 - 0x468]
   65c78: 7b 1a 48 fd 00 00 00 00      	stxdw [r10 - 0x2b8], r1
   65c80: 79 a1 18 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e8]
   65c88: 7b 1a 40 fd 00 00 00 00      	stxdw [r10 - 0x2c0], r1
   65c90: 79 a1 60 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4a0]
   65c98: 7b 1a 38 fd 00 00 00 00      	stxdw [r10 - 0x2c8], r1
   65ca0: 79 a1 a0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x460]
   65ca8: 73 1a 32 fd 00 00 00 00      	stxb [r10 - 0x2ce], r1
   65cb0: 79 a1 a8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x458]
   65cb8: 73 1a 31 fd 00 00 00 00      	stxb [r10 - 0x2cf], r1
   65cc0: 79 a1 b0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x450]
   65cc8: 73 1a 30 fd 00 00 00 00      	stxb [r10 - 0x2d0], r1
   65cd0: 79 a1 b8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x448]
   65cd8: 7b 1a 28 fd 00 00 00 00      	stxdw [r10 - 0x2d8], r1
   65ce0: 79 a1 c0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x440]
   65ce8: 7b 1a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r1
   65cf0: 79 a1 c8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x438]
   65cf8: 7b 1a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r1
   65d00: 79 a1 20 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e0]
   65d08: 7b 1a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r1
   65d10: 79 a1 d0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x430]
   65d18: 7b 1a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r1
   65d20: 79 a1 d8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x428]
   65d28: 73 1a 02 fd 00 00 00 00      	stxb [r10 - 0x2fe], r1
   65d30: 79 a1 e0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x420]
   65d38: 73 1a 01 fd 00 00 00 00      	stxb [r10 - 0x2ff], r1
   65d40: 79 a1 e8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x418]
   65d48: 73 1a 00 fd 00 00 00 00      	stxb [r10 - 0x300], r1
   65d50: 79 a1 f0 fb 00 00 00 00      	ldxdw r1, [r10 - 0x410]
   65d58: 7b 1a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r1
   65d60: 79 a1 f8 fb 00 00 00 00      	ldxdw r1, [r10 - 0x408]
   65d68: 7b 1a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r1
   65d70: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   65d78: 7b 1a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r1
   65d80: 79 a1 28 fb 00 00 00 00      	ldxdw r1, [r10 - 0x4d8]
   65d88: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   65d90: 79 a1 08 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f8]
   65d98: 7b 1a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r1
   65da0: 79 a1 40 ff 00 00 00 00      	ldxdw r1, [r10 - 0xc0]
   65da8: 7b 1a 08 fe 00 00 00 00      	stxdw [r10 - 0x1f8], r1
   65db0: 79 a1 48 ff 00 00 00 00      	ldxdw r1, [r10 - 0xb8]
   65db8: 7b 1a 10 fe 00 00 00 00      	stxdw [r10 - 0x1f0], r1
   65dc0: 79 a1 50 ff 00 00 00 00      	ldxdw r1, [r10 - 0xb0]
   65dc8: 7b 1a 18 fe 00 00 00 00      	stxdw [r10 - 0x1e8], r1
   65dd0: 79 a1 58 ff 00 00 00 00      	ldxdw r1, [r10 - 0xa8]
   65dd8: 7b 1a 20 fe 00 00 00 00      	stxdw [r10 - 0x1e0], r1
   65de0: 7a 0a d0 fc 00 00 00 00      	stdw [r10 - 0x330], 0x0
   65de8: 7a 0a c8 fc 08 00 00 00      	stdw [r10 - 0x338], 0x8
   65df0: 7a 0a c0 fc 00 00 00 00      	stdw [r10 - 0x340], 0x0
   65df8: 7a 0a f8 fd 08 00 00 00      	stdw [r10 - 0x208], 0x8
   65e00: 7a 0a 00 fe 00 00 00 00      	stdw [r10 - 0x200], 0x0
   65e08: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   65e10: 07 01 00 00 b0 fc ff ff      	add64 r1, -0x350
   65e18: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   65e20: 07 02 00 00 c0 fc ff ff      	add64 r2, -0x340
   65e28: 85 10 00 00 f0 31 00 00      	call 0x31f0
   65e30: 79 a1 b0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x350]
   65e38: 55 01 cf 00 02 00 00 00      	jne r1, 0x2, +0xcf <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1090>
   65e40: 79 a1 e0 fa 00 00 00 00      	ldxdw r1, [r10 - 0x520]
   65e48: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   65e50: 79 a8 28 fc 00 00 00 00      	ldxdw r8, [r10 - 0x3d8]
   65e58: 79 a7 e8 fa 00 00 00 00      	ldxdw r7, [r10 - 0x518]
   65e60: 79 a9 f0 fa 00 00 00 00      	ldxdw r9, [r10 - 0x510]
   65e68: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   65e70: 07 01 00 00 28 fe ff ff      	add64 r1, -0x1d8
   65e78: 85 10 00 00 10 3a ff ff      	call -0xc5f0
   65e80: 61 a1 d8 fe 00 00 00 00      	ldxw r1, [r10 - 0x128]
   65e88: 55 01 24 00 02 00 00 00      	jne r1, 0x2, +0x24 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xb88>
   65e90: 79 a6 30 fe 00 00 00 00      	ldxdw r6, [r10 - 0x1d0]
   65e98: 79 a7 28 fe 00 00 00 00      	ldxdw r7, [r10 - 0x1d8]
   65ea0: 85 10 00 00 4c 31 00 00      	call 0x314c
   65ea8: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   65eb8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   65ec0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   65ec8: 07 01 00 00 ee ff ff ff      	add64 r1, -0x12
   65ed0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   65ed8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   65ee0: 2d 21 7f 00 00 00 00 00      	jgt r1, r2, +0x7f <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xeb8>
   65ee8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   65ef0: 15 04 7e 00 00 00 00 00      	jeq r4, 0x0, +0x7e <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xec0>
   65ef8: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   65f08: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xaf0>
   65f10: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   65f18: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   65f28: bd 21 54 01 00 00 00 00      	jle r1, r2, +0x154 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x15a8>
   65f30: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   65f40: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   65f48: 18 02 00 00 6f 6b 65 6e 00 00 00 00 5f 76 61 75      	lddw r2, 0x7561765f6e656b6f
   65f58: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   65f60: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 74      	lddw r2, 0x745f6d656879616d
   65f70: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   65f78: 6a 01 10 00 6c 74 00 00      	sth [r1 + 0x10], 0x746c
   65f80: 79 62 00 00 00 00 00 00      	ldxdw r2, [r6 + 0x0]
   65f88: 7b 16 10 00 00 00 00 00      	stxdw [r6 + 0x10], r1
   65f90: 7a 06 18 00 12 00 00 00      	stdw [r6 + 0x18], 0x12
   65f98: 7a 06 08 00 12 00 00 00      	stdw [r6 + 0x8], 0x12
   65fa0: 7a 06 00 00 01 00 00 00      	stdw [r6 + 0x0], 0x1
   65fa8: 05 00 7e 01 00 00 00 00      	ja +0x17e <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1778>
   65fb0: 79 a1 40 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c0]
   65fb8: 7b 1a d8 fc 00 00 00 00      	stxdw [r10 - 0x328], r1
   65fc0: 79 a1 38 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1c8]
   65fc8: 7b 1a d0 fc 00 00 00 00      	stxdw [r10 - 0x330], r1
   65fd0: 79 a1 30 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d0]
   65fd8: 7b 1a c8 fc 00 00 00 00      	stxdw [r10 - 0x338], r1
   65fe0: 79 a1 28 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1d8]
   65fe8: 7b 1a c0 fc 00 00 00 00      	stxdw [r10 - 0x340], r1
   65ff0: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   65ff8: 7b 1a 20 ff 00 00 00 00      	stxdw [r10 - 0xe0], r1
   66000: 79 a1 58 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a8]
   66008: 7b 1a 28 ff 00 00 00 00      	stxdw [r10 - 0xd8], r1
   66010: 79 a1 60 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a0]
   66018: 7b 1a 30 ff 00 00 00 00      	stxdw [r10 - 0xd0], r1
   66020: 79 a1 68 fe 00 00 00 00      	ldxdw r1, [r10 - 0x198]
   66028: 7b 1a 38 ff 00 00 00 00      	stxdw [r10 - 0xc8], r1
   66030: 79 a6 48 fe 00 00 00 00      	ldxdw r6, [r10 - 0x1b8]
   66038: 79 a1 88 fe 00 00 00 00      	ldxdw r1, [r10 - 0x178]
   66040: 7b 1a 18 ff 00 00 00 00      	stxdw [r10 - 0xe8], r1
   66048: 79 a1 80 fe 00 00 00 00      	ldxdw r1, [r10 - 0x180]
   66050: 7b 1a 10 ff 00 00 00 00      	stxdw [r10 - 0xf0], r1
   66058: 79 a1 78 fe 00 00 00 00      	ldxdw r1, [r10 - 0x188]
   66060: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
   66068: 79 a1 70 fe 00 00 00 00      	ldxdw r1, [r10 - 0x190]
   66070: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   66078: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   66080: 07 01 00 00 28 fd ff ff      	add64 r1, -0x2d8
   66088: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   66090: 07 02 00 00 90 fe ff ff      	add64 r2, -0x170
   66098: b7 03 00 00 70 00 00 00      	mov64 r3, 0x70
   660a0: 85 10 00 00 55 64 00 00      	call 0x6455
   660a8: 79 a1 50 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1b0]
   660b0: 7b 1a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r1
   660b8: 79 a1 58 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a8]
   660c0: 7b 1a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r1
   660c8: 79 a1 60 fe 00 00 00 00      	ldxdw r1, [r10 - 0x1a0]
   660d0: 7b 1a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r1
   660d8: 79 a1 68 fe 00 00 00 00      	ldxdw r1, [r10 - 0x198]
   660e0: 7b 1a 00 fd 00 00 00 00      	stxdw [r10 - 0x300], r1
   660e8: 79 a1 70 fe 00 00 00 00      	ldxdw r1, [r10 - 0x190]
   660f0: 7b 1a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r1
   660f8: 79 a1 78 fe 00 00 00 00      	ldxdw r1, [r10 - 0x188]
   66100: 7b 1a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r1
   66108: 79 a1 80 fe 00 00 00 00      	ldxdw r1, [r10 - 0x180]
   66110: 7b 1a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r1
   66118: 79 a1 88 fe 00 00 00 00      	ldxdw r1, [r10 - 0x178]
   66120: 7b 1a 20 fd 00 00 00 00      	stxdw [r10 - 0x2e0], r1
   66128: 7b 6a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r6
   66130: bf 90 00 00 00 00 00 00      	mov64 r0, r9
   66138: 79 99 20 00 00 00 00 00      	ldxdw r9, [r9 + 0x20]
   66140: 79 91 58 00 00 00 00 00      	ldxdw r1, [r9 + 0x58]
   66148: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   66150: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   66158: 7b 2a 58 ff 00 00 00 00      	stxdw [r10 - 0xa8], r2
   66160: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   66168: 7b 2a 50 ff 00 00 00 00      	stxdw [r10 - 0xb0], r2
   66170: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   66178: 7b 2a 48 ff 00 00 00 00      	stxdw [r10 - 0xb8], r2
   66180: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   66188: 7b 2a 40 ff 00 00 00 00      	stxdw [r10 - 0xc0], r2
   66190: 79 a3 e8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x318]
   66198: 5d 23 0a 00 00 00 00 00      	jne r3, r2, +0xa <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xdc8>
   661a0: 79 a2 48 ff 00 00 00 00      	ldxdw r2, [r10 - 0xb8]
   661a8: 79 a3 f0 fc 00 00 00 00      	ldxdw r3, [r10 - 0x310]
   661b0: 5d 23 07 00 00 00 00 00      	jne r3, r2, +0x7 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xdc8>
   661b8: 79 a2 50 ff 00 00 00 00      	ldxdw r2, [r10 - 0xb0]
   661c0: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   661c8: 5d 23 04 00 00 00 00 00      	jne r3, r2, +0x4 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xdc8>
   661d0: b7 02 00 00 00 00 00 00      	mov64 r2, 0x0
   661d8: 79 a3 58 ff 00 00 00 00      	ldxdw r3, [r10 - 0xa8]
   661e0: 79 a4 00 fd 00 00 00 00      	ldxdw r4, [r10 - 0x300]
   661e8: 1d 34 01 00 00 00 00 00      	jeq r4, r3, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xdd0>
   661f0: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   661f8: 7b 8a 28 fc 00 00 00 00      	stxdw [r10 - 0x3d8], r8
   66200: 15 02 5c 00 00 00 00 00      	jeq r2, 0x0, +0x5c <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x10c0>
   66208: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   66210: 07 01 00 00 a0 fc ff ff      	add64 r1, -0x360
   66218: b7 02 00 00 de 07 00 00      	mov64 r2, 0x7de
   66220: 85 10 00 00 c6 43 00 00      	call 0x43c6
   66228: 79 a7 a8 fc 00 00 00 00      	ldxdw r7, [r10 - 0x358]
   66230: 79 a8 a0 fc 00 00 00 00      	ldxdw r8, [r10 - 0x360]
   66238: 85 10 00 00 d9 30 00 00      	call 0x30d9
   66240: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   66250: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   66258: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   66260: 07 01 00 00 ee ff ff ff      	add64 r1, -0x12
   66268: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   66270: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   66278: 2d 21 12 00 00 00 00 00      	jgt r1, r2, +0x12 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xee8>
   66280: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   66288: 15 04 11 00 00 00 00 00      	jeq r4, 0x0, +0x11 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xef0>
   66290: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   662a0: 15 02 12 00 00 00 00 00      	jeq r2, 0x0, +0x12 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xf10>
   662a8: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   662b0: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   662b8: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   662c0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   662d0: 2d 21 11 00 00 00 00 00      	jgt r1, r2, +0x11 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xf38>
   662d8: 05 00 de 00 00 00 00 00      	ja +0xde <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x15a8>
   662e0: 55 04 82 ff 00 00 00 00      	jne r4, 0x0, -0x7e <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xad0>
   662e8: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   662f0: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   66300: 15 02 82 ff 00 00 00 00      	jeq r2, 0x0, -0x7e <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xaf0>
   66308: 05 00 80 ff 00 00 00 00      	ja -0x80 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xae8>
   66310: 55 04 ef ff 00 00 00 00      	jne r4, 0x0, -0x11 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xe68>
   66318: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   66320: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   66330: 55 02 ee ff 00 00 00 00      	jne r2, 0x0, -0x12 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xe80>
   66338: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   66340: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   66348: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   66358: bd 21 ce 00 00 00 00 00      	jle r1, r2, +0xce <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x15a8>
   66360: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   66370: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   66378: 18 02 00 00 6f 6b 65 6e 00 00 00 00 5f 76 61 75      	lddw r2, 0x7561765f6e656b6f
   66388: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   66390: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 74      	lddw r2, 0x745f6d656879616d
   663a0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   663a8: 6a 01 10 00 6c 74 00 00      	sth [r1 + 0x10], 0x746c
   663b0: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   663b8: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   663c0: 7a 07 18 00 12 00 00 00      	stdw [r7 + 0x18], 0x12
   663c8: 7a 07 08 00 12 00 00 00      	stdw [r7 + 0x8], 0x12
   663d0: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   663d8: 79 a1 38 ff 00 00 00 00      	ldxdw r1, [r10 - 0xc8]
   663e0: 7b 1a 58 ff 00 00 00 00      	stxdw [r10 - 0xa8], r1
   663e8: 79 a1 30 ff 00 00 00 00      	ldxdw r1, [r10 - 0xd0]
   663f0: 7b 1a 50 ff 00 00 00 00      	stxdw [r10 - 0xb0], r1
   663f8: 79 a1 28 ff 00 00 00 00      	ldxdw r1, [r10 - 0xd8]
   66400: 7b 1a 48 ff 00 00 00 00      	stxdw [r10 - 0xb8], r1
   66408: 79 a1 20 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe0]
   66410: 7b 1a 40 ff 00 00 00 00      	stxdw [r10 - 0xc0], r1
   66418: 79 91 58 00 00 00 00 00      	ldxdw r1, [r9 + 0x58]
   66420: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   66428: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   66430: 7b 2a 78 ff 00 00 00 00      	stxdw [r10 - 0x88], r2
   66438: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   66440: 7b 2a 70 ff 00 00 00 00      	stxdw [r10 - 0x90], r2
   66448: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   66450: 7b 2a 68 ff 00 00 00 00      	stxdw [r10 - 0x98], r2
   66458: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   66460: 7b 1a 60 ff 00 00 00 00      	stxdw [r10 - 0xa0], r1
   66468: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   66470: 07 01 00 00 90 fc ff ff      	add64 r1, -0x370
   66478: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   66480: 07 04 00 00 40 ff ff ff      	add64 r4, -0xc0
   66488: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   66490: bf 73 00 00 00 00 00 00      	mov64 r3, r7
   66498: 85 10 00 00 de 3d 00 00      	call 0x3dde
   664a0: 79 a6 98 fc 00 00 00 00      	ldxdw r6, [r10 - 0x368]
   664a8: 79 a7 90 fc 00 00 00 00      	ldxdw r7, [r10 - 0x370]
   664b0: 05 00 dc 00 00 00 00 00      	ja +0xdc <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1770>
   664b8: 79 a2 b8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x348]
   664c0: 79 a3 28 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3d8]
   664c8: 7b 13 00 00 00 00 00 00      	stxdw [r3 + 0x0], r1
   664d0: 7b 23 08 00 00 00 00 00      	stxdw [r3 + 0x8], r2
   664d8: 62 03 b0 00 02 00 00 00      	stw [r3 + 0xb0], 0x2
   664e0: 05 00 da 00 00 00 00 00      	ja +0xda <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1790>
   664e8: 79 09 18 00 00 00 00 00      	ldxdw r9, [r0 + 0x18]
   664f0: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   664f8: 79 22 00 00 00 00 00 00      	ldxdw r2, [r2 + 0x0]
   66500: 79 23 18 00 00 00 00 00      	ldxdw r3, [r2 + 0x18]
   66508: 7b 3a 58 ff 00 00 00 00      	stxdw [r10 - 0xa8], r3
   66510: 79 23 10 00 00 00 00 00      	ldxdw r3, [r2 + 0x10]
   66518: 7b 3a 50 ff 00 00 00 00      	stxdw [r10 - 0xb0], r3
   66520: 79 23 08 00 00 00 00 00      	ldxdw r3, [r2 + 0x8]
   66528: 7b 3a 48 ff 00 00 00 00      	stxdw [r10 - 0xb8], r3
   66530: 79 23 00 00 00 00 00 00      	ldxdw r3, [r2 + 0x0]
   66538: 7b 3a 40 ff 00 00 00 00      	stxdw [r10 - 0xc0], r3
   66540: 79 a4 08 fd 00 00 00 00      	ldxdw r4, [r10 - 0x2f8]
   66548: 5d 34 0a 00 00 00 00 00      	jne r4, r3, +0xa <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1178>
   66550: 79 a3 48 ff 00 00 00 00      	ldxdw r3, [r10 - 0xb8]
   66558: 79 a4 10 fd 00 00 00 00      	ldxdw r4, [r10 - 0x2f0]
   66560: 5d 34 07 00 00 00 00 00      	jne r4, r3, +0x7 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1178>
   66568: 79 a3 50 ff 00 00 00 00      	ldxdw r3, [r10 - 0xb0]
   66570: 79 a4 18 fd 00 00 00 00      	ldxdw r4, [r10 - 0x2e8]
   66578: 5d 34 04 00 00 00 00 00      	jne r4, r3, +0x4 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1178>
   66580: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   66588: 79 a4 58 ff 00 00 00 00      	ldxdw r4, [r10 - 0xa8]
   66590: 79 a5 20 fd 00 00 00 00      	ldxdw r5, [r10 - 0x2e0]
   66598: 1d 45 01 00 00 00 00 00      	jeq r5, r4, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1180>
   665a0: b7 03 00 00 01 00 00 00      	mov64 r3, 0x1
   665a8: 15 03 50 00 00 00 00 00      	jeq r3, 0x0, +0x50 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1408>
   665b0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   665b8: 07 01 00 00 80 fc ff ff      	add64 r1, -0x380
   665c0: b7 02 00 00 df 07 00 00      	mov64 r2, 0x7df
   665c8: 85 10 00 00 51 43 00 00      	call 0x4351
   665d0: 79 a7 88 fc 00 00 00 00      	ldxdw r7, [r10 - 0x378]
   665d8: 79 a8 80 fc 00 00 00 00      	ldxdw r8, [r10 - 0x380]
   665e0: 85 10 00 00 64 30 00 00      	call 0x3064
   665e8: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   665f8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   66600: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   66608: 07 01 00 00 ee ff ff ff      	add64 r1, -0x12
   66610: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   66618: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   66620: 2d 21 0c 00 00 00 00 00      	jgt r1, r2, +0xc <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1260>
   66628: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   66630: 15 04 0b 00 00 00 00 00      	jeq r4, 0x0, +0xb <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1268>
   66638: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   66648: 15 02 0c 00 00 00 00 00      	jeq r2, 0x0, +0xc <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1288>
   66650: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   66658: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   66660: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   66668: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   66678: 2d 21 0b 00 00 00 00 00      	jgt r1, r2, +0xb <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x12b0>
   66680: 05 00 69 00 00 00 00 00      	ja +0x69 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x15a8>
   66688: 55 04 f5 ff 00 00 00 00      	jne r4, 0x0, -0xb <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1210>
   66690: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   66698: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   666a8: 55 02 f4 ff 00 00 00 00      	jne r2, 0x0, -0xc <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1228>
   666b0: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   666b8: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   666c0: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   666d0: bd 21 5f 00 00 00 00 00      	jle r1, r2, +0x5f <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x15a8>
   666d8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   666e8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   666f0: 18 02 00 00 6f 6b 65 6e 00 00 00 00 5f 76 61 75      	lddw r2, 0x7561765f6e656b6f
   66700: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   66708: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 74      	lddw r2, 0x745f6d656879616d
   66718: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   66720: 6a 01 10 00 6c 74 00 00      	sth [r1 + 0x10], 0x746c
   66728: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   66730: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   66738: 7a 07 18 00 12 00 00 00      	stdw [r7 + 0x18], 0x12
   66740: 7a 07 08 00 12 00 00 00      	stdw [r7 + 0x8], 0x12
   66748: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   66750: 79 a1 18 ff 00 00 00 00      	ldxdw r1, [r10 - 0xe8]
   66758: 7b 1a 58 ff 00 00 00 00      	stxdw [r10 - 0xa8], r1
   66760: 79 a1 10 ff 00 00 00 00      	ldxdw r1, [r10 - 0xf0]
   66768: 7b 1a 50 ff 00 00 00 00      	stxdw [r10 - 0xb0], r1
   66770: 79 a1 08 ff 00 00 00 00      	ldxdw r1, [r10 - 0xf8]
   66778: 7b 1a 48 ff 00 00 00 00      	stxdw [r10 - 0xb8], r1
   66780: 79 a1 00 ff 00 00 00 00      	ldxdw r1, [r10 - 0x100]
   66788: 7b 1a 40 ff 00 00 00 00      	stxdw [r10 - 0xc0], r1
   66790: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   66798: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   667a0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   667a8: 7b 2a 78 ff 00 00 00 00      	stxdw [r10 - 0x88], r2
   667b0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   667b8: 7b 2a 70 ff 00 00 00 00      	stxdw [r10 - 0x90], r2
   667c0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   667c8: 7b 2a 68 ff 00 00 00 00      	stxdw [r10 - 0x98], r2
   667d0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   667d8: 7b 1a 60 ff 00 00 00 00      	stxdw [r10 - 0xa0], r1
   667e0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   667e8: 07 01 00 00 70 fc ff ff      	add64 r1, -0x390
   667f0: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   667f8: 07 04 00 00 40 ff ff ff      	add64 r4, -0xc0
   66800: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   66808: bf 73 00 00 00 00 00 00      	mov64 r3, r7
   66810: 85 10 00 00 6f 3d 00 00      	call 0x3d6f
   66818: 79 a6 78 fc 00 00 00 00      	ldxdw r6, [r10 - 0x388]
   66820: 79 a7 70 fc 00 00 00 00      	ldxdw r7, [r10 - 0x390]
   66828: 05 00 6d 00 00 00 00 00      	ja +0x6d <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1770>
   66830: 79 09 30 00 00 00 00 00      	ldxdw r9, [r0 + 0x30]
   66838: 79 93 00 00 00 00 00 00      	ldxdw r3, [r9 + 0x0]
   66840: 79 33 00 00 00 00 00 00      	ldxdw r3, [r3 + 0x0]
   66848: 79 34 18 00 00 00 00 00      	ldxdw r4, [r3 + 0x18]
   66850: 7b 4a 58 ff 00 00 00 00      	stxdw [r10 - 0xa8], r4
   66858: 79 34 10 00 00 00 00 00      	ldxdw r4, [r3 + 0x10]
   66860: 7b 4a 50 ff 00 00 00 00      	stxdw [r10 - 0xb0], r4
   66868: 79 34 08 00 00 00 00 00      	ldxdw r4, [r3 + 0x8]
   66870: 7b 4a 48 ff 00 00 00 00      	stxdw [r10 - 0xb8], r4
   66878: 79 34 00 00 00 00 00 00      	ldxdw r4, [r3 + 0x0]
   66880: 7b 4a 40 ff 00 00 00 00      	stxdw [r10 - 0xc0], r4
   66888: 79 75 00 00 00 00 00 00      	ldxdw r5, [r7 + 0x0]
   66890: 5d 45 0a 00 00 00 00 00      	jne r5, r4, +0xa <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x14c0>
   66898: 79 74 08 00 00 00 00 00      	ldxdw r4, [r7 + 0x8]
   668a0: 79 a5 48 ff 00 00 00 00      	ldxdw r5, [r10 - 0xb8]
   668a8: 5d 54 07 00 00 00 00 00      	jne r4, r5, +0x7 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x14c0>
   668b0: 79 74 10 00 00 00 00 00      	ldxdw r4, [r7 + 0x10]
   668b8: 79 a5 50 ff 00 00 00 00      	ldxdw r5, [r10 - 0xb0]
   668c0: 5d 54 04 00 00 00 00 00      	jne r4, r5, +0x4 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x14c0>
   668c8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   668d0: 79 75 18 00 00 00 00 00      	ldxdw r5, [r7 + 0x18]
   668d8: 79 a0 58 ff 00 00 00 00      	ldxdw r0, [r10 - 0xa8]
   668e0: 1d 05 01 00 00 00 00 00      	jeq r5, r0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x14c8>
   668e8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   668f0: 15 04 59 00 00 00 00 00      	jeq r4, 0x0, +0x59 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1798>
   668f8: bf 76 00 00 00 00 00 00      	mov64 r6, r7
   66900: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   66908: 07 01 00 00 60 fc ff ff      	add64 r1, -0x3a0
   66910: b7 02 00 00 e7 07 00 00      	mov64 r2, 0x7e7
   66918: 85 10 00 00 e7 42 00 00      	call 0x42e7
   66920: 79 a7 68 fc 00 00 00 00      	ldxdw r7, [r10 - 0x398]
   66928: 79 a8 60 fc 00 00 00 00      	ldxdw r8, [r10 - 0x3a0]
   66930: 85 10 00 00 fa 2f 00 00      	call 0x2ffa
   66938: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   66948: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   66950: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   66958: 07 01 00 00 ee ff ff ff      	add64 r1, -0x12
   66960: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   66968: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   66970: 2d 21 10 00 00 00 00 00      	jgt r1, r2, +0x10 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x15d0>
   66978: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   66980: 15 04 0f 00 00 00 00 00      	jeq r4, 0x0, +0xf <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x15d8>
   66988: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   66998: 15 02 10 00 00 00 00 00      	jeq r2, 0x0, +0x10 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x15f8>
   669a0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   669a8: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   669b0: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   669b8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   669c8: 2d 21 0f 00 00 00 00 00      	jgt r1, r2, +0xf <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1620>
   669d0: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   669d8: b7 02 00 00 12 00 00 00      	mov64 r2, 0x12
   669e0: 18 03 00 00 10 eb 09 00 00 00 00 00 00 00 00 00      	lddw r3, 0x9eb10
   669f0: 85 10 00 00 6b 55 00 00      	call 0x556b
   669f8: 55 04 f1 ff 00 00 00 00      	jne r4, 0x0, -0xf <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1560>
   66a00: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   66a08: 18 01 00 00 ee 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007fee
   66a18: 55 02 f0 ff 00 00 00 00      	jne r2, 0x0, -0x10 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1578>
   66a20: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   66a28: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   66a30: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   66a40: bd 21 f1 ff 00 00 00 00      	jle r1, r2, -0xf <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x15a8>
   66a48: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   66a58: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   66a60: 18 02 00 00 6f 6b 65 6e 00 00 00 00 5f 76 61 75      	lddw r2, 0x7561765f6e656b6f
   66a70: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   66a78: 18 02 00 00 6d 61 79 68 00 00 00 00 65 6d 5f 74      	lddw r2, 0x745f6d656879616d
   66a88: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   66a90: 6a 01 10 00 6c 74 00 00      	sth [r1 + 0x10], 0x746c
   66a98: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   66aa0: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   66aa8: 7a 07 18 00 12 00 00 00      	stdw [r7 + 0x18], 0x12
   66ab0: 7a 07 08 00 12 00 00 00      	stdw [r7 + 0x8], 0x12
   66ab8: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   66ac0: 79 61 18 00 00 00 00 00      	ldxdw r1, [r6 + 0x18]
   66ac8: 7b 1a 58 ff 00 00 00 00      	stxdw [r10 - 0xa8], r1
   66ad0: 79 61 10 00 00 00 00 00      	ldxdw r1, [r6 + 0x10]
   66ad8: 7b 1a 50 ff 00 00 00 00      	stxdw [r10 - 0xb0], r1
   66ae0: 79 61 08 00 00 00 00 00      	ldxdw r1, [r6 + 0x8]
   66ae8: 7b 1a 48 ff 00 00 00 00      	stxdw [r10 - 0xb8], r1
   66af0: 79 61 00 00 00 00 00 00      	ldxdw r1, [r6 + 0x0]
   66af8: 7b 1a 40 ff 00 00 00 00      	stxdw [r10 - 0xc0], r1
   66b00: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   66b08: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   66b10: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   66b18: 7b 2a 78 ff 00 00 00 00      	stxdw [r10 - 0x88], r2
   66b20: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   66b28: 7b 2a 70 ff 00 00 00 00      	stxdw [r10 - 0x90], r2
   66b30: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   66b38: 7b 2a 68 ff 00 00 00 00      	stxdw [r10 - 0x98], r2
   66b40: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   66b48: 7b 1a 60 ff 00 00 00 00      	stxdw [r10 - 0xa0], r1
   66b50: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   66b58: 07 01 00 00 50 fc ff ff      	add64 r1, -0x3b0
   66b60: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   66b68: 07 04 00 00 40 ff ff ff      	add64 r4, -0xc0
   66b70: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   66b78: bf 73 00 00 00 00 00 00      	mov64 r3, r7
   66b80: 85 10 00 00 01 3d 00 00      	call 0x3d01
   66b88: 79 a6 58 fc 00 00 00 00      	ldxdw r6, [r10 - 0x3a8]
   66b90: 79 a7 50 fc 00 00 00 00      	ldxdw r7, [r10 - 0x3b0]
   66b98: 79 a8 28 fc 00 00 00 00      	ldxdw r8, [r10 - 0x3d8]
   66ba0: 7b 68 08 00 00 00 00 00      	stxdw [r8 + 0x8], r6
   66ba8: 7b 78 00 00 00 00 00 00      	stxdw [r8 + 0x0], r7
   66bb0: 62 08 b0 00 02 00 00 00      	stw [r8 + 0xb0], 0x2
   66bb8: 95 00 00 00 00 00 00 00      	exit
   66bc0: 79 64 00 00 00 00 00 00      	ldxdw r4, [r6 + 0x0]
   66bc8: 79 45 18 00 00 00 00 00      	ldxdw r5, [r4 + 0x18]
   66bd0: 7b 5a 98 ff 00 00 00 00      	stxdw [r10 - 0x68], r5
   66bd8: 79 45 10 00 00 00 00 00      	ldxdw r5, [r4 + 0x10]
   66be0: 7b 5a 90 ff 00 00 00 00      	stxdw [r10 - 0x70], r5
   66be8: 79 45 08 00 00 00 00 00      	ldxdw r5, [r4 + 0x8]
   66bf0: 7b 5a 88 ff 00 00 00 00      	stxdw [r10 - 0x78], r5
   66bf8: 79 44 00 00 00 00 00 00      	ldxdw r4, [r4 + 0x0]
   66c00: 7b 4a 80 ff 00 00 00 00      	stxdw [r10 - 0x80], r4
   66c08: 79 24 18 00 00 00 00 00      	ldxdw r4, [r2 + 0x18]
   66c10: 7b 4a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r4
   66c18: 79 24 10 00 00 00 00 00      	ldxdw r4, [r2 + 0x10]
   66c20: 7b 4a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r4
   66c28: 79 24 08 00 00 00 00 00      	ldxdw r4, [r2 + 0x8]
   66c30: 7b 4a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r4
   66c38: 79 22 00 00 00 00 00 00      	ldxdw r2, [r2 + 0x0]
   66c40: 7b 2a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r2
   66c48: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   66c50: 7b 2a f8 ff 00 00 00 00      	stxdw [r10 - 0x8], r2
   66c58: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   66c60: 7b 2a f0 ff 00 00 00 00      	stxdw [r10 - 0x10], r2
   66c68: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   66c70: 7b 2a e8 ff 00 00 00 00      	stxdw [r10 - 0x18], r2
   66c78: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   66c80: 7b 1a e0 ff 00 00 00 00      	stxdw [r10 - 0x20], r1
   66c88: 79 31 18 00 00 00 00 00      	ldxdw r1, [r3 + 0x18]
   66c90: 7b 1a 58 ff 00 00 00 00      	stxdw [r10 - 0xa8], r1
   66c98: 79 31 10 00 00 00 00 00      	ldxdw r1, [r3 + 0x10]
   66ca0: 7b 1a 50 ff 00 00 00 00      	stxdw [r10 - 0xb0], r1
   66ca8: 79 31 08 00 00 00 00 00      	ldxdw r1, [r3 + 0x8]
   66cb0: 7b 1a 48 ff 00 00 00 00      	stxdw [r10 - 0xb8], r1
   66cb8: 79 31 00 00 00 00 00 00      	ldxdw r1, [r3 + 0x0]
   66cc0: 7b 1a 40 ff 00 00 00 00      	stxdw [r10 - 0xc0], r1
   66cc8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   66cd0: 07 01 00 00 a0 ff ff ff      	add64 r1, -0x60
   66cd8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   66ce0: 07 02 00 00 c0 ff ff ff      	add64 r2, -0x40
   66ce8: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   66cf0: 07 03 00 00 e0 ff ff ff      	add64 r3, -0x20
   66cf8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   66d00: 07 04 00 00 40 ff ff ff      	add64 r4, -0xc0
   66d08: 85 10 00 00 34 39 00 00      	call 0x3934
   66d10: 79 a1 a0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x60]
   66d18: 79 a2 80 ff 00 00 00 00      	ldxdw r2, [r10 - 0x80]
   66d20: 5d 12 0a 00 00 00 00 00      	jne r2, r1, +0xa <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1950>
   66d28: 79 a1 a8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x58]
   66d30: 79 a2 88 ff 00 00 00 00      	ldxdw r2, [r10 - 0x78]
   66d38: 5d 12 07 00 00 00 00 00      	jne r2, r1, +0x7 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1950>
   66d40: 79 a1 b0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x50]
   66d48: 79 a2 90 ff 00 00 00 00      	ldxdw r2, [r10 - 0x70]
   66d50: 5d 12 04 00 00 00 00 00      	jne r2, r1, +0x4 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1950>
   66d58: b7 01 00 00 00 00 00 00      	mov64 r1, 0x0
   66d60: 79 a2 b8 ff 00 00 00 00      	ldxdw r2, [r10 - 0x48]
   66d68: 79 a3 98 ff 00 00 00 00      	ldxdw r3, [r10 - 0x68]
   66d70: 1d 23 01 00 00 00 00 00      	jeq r3, r2, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1958>
   66d78: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   66d80: 15 01 12 00 00 00 00 00      	jeq r1, 0x0, +0x12 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x19f0>
   66d88: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   66d90: 07 01 00 00 40 fc ff ff      	add64 r1, -0x3c0
   66d98: b7 02 00 00 c6 0b 00 00      	mov64 r2, 0xbc6
   66da0: 85 10 00 00 56 42 00 00      	call 0x4256
   66da8: 79 a3 48 fc 00 00 00 00      	ldxdw r3, [r10 - 0x3b8]
   66db0: 79 a2 40 fc 00 00 00 00      	ldxdw r2, [r10 - 0x3c0]
   66db8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   66dc0: 07 01 00 00 30 fc ff ff      	add64 r1, -0x3d0
   66dc8: 18 04 00 00 c4 b3 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9b3c4
   66dd8: b7 05 00 00 12 00 00 00      	mov64 r5, 0x12
   66de0: 85 10 00 00 bb 37 ff ff      	call -0xc845
   66de8: 79 a6 38 fc 00 00 00 00      	ldxdw r6, [r10 - 0x3c8]
   66df0: 79 a7 30 fc 00 00 00 00      	ldxdw r7, [r10 - 0x3d0]
   66df8: 05 00 b4 ff 00 00 00 00      	ja -0x4c <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1778>
   66e00: b7 01 00 00 00 00 00 00      	mov64 r1, 0x0
   66e08: 55 01 0b fe 00 00 00 00      	jne r1, 0x0, -0x1f5 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0xa40>
   66e10: 05 00 d1 fc 00 00 00 00      	ja -0x32f <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x78>
   66e18: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   66e20: 07 02 00 00 28 fe ff ff      	add64 r2, -0x1d8
   66e28: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   66e30: b7 03 00 00 d8 00 00 00      	mov64 r3, 0xd8
   66e38: 85 10 00 00 a2 62 00 00      	call 0x62a2
   66e40: 05 00 ae ff 00 00 00 00      	ja -0x52 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts28_$u7b$$u7b$closure$u7d$$u7d$17h3aa0b72c94579563E+0x1790>
   66e48: 85 10 00 00 ff ff ff ff      	call -0x1
