
/Users/symbiex/dev/austin/lalalune/mayhem-initializer-recovery-20261026/vault-reuse/build/target/sbf-solana-solana/release/mayhem_recovered.so:	file format elf64-sbf

Disassembly of section .text:

0000000000062ad8 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE>:
   62ad8: bf 57 00 00 00 00 00 00      	mov64 r7, r5
   62ae0: bf 38 00 00 00 00 00 00      	mov64 r8, r3
   62ae8: 7b 1a c0 f6 00 00 00 00      	stxdw [r10 - 0x940], r1
   62af0: 7b 2a 08 f9 00 00 00 00      	stxdw [r10 - 0x6f8], r2
   62af8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62b00: 07 01 00 00 18 f9 ff ff      	add64 r1, -0x6e8
   62b08: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   62b10: 85 10 00 00 83 55 ff ff      	call -0xaa7d
   62b18: 79 a9 20 f9 00 00 00 00      	ldxdw r9, [r10 - 0x6e0]
   62b20: 79 a6 18 f9 00 00 00 00      	ldxdw r6, [r10 - 0x6e8]
   62b28: 55 06 33 00 02 00 00 00      	jne r6, 0x2, +0x33 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1f0>
   62b30: 79 76 08 f0 00 00 00 00      	ldxdw r6, [r7 - 0xff8]
   62b38: 7b 9a 10 f9 00 00 00 00      	stxdw [r10 - 0x6f0], r9
   62b40: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62b48: 07 01 00 00 28 f9 ff ff      	add64 r1, -0x6d8
   62b50: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   62b58: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   62b60: 85 10 00 00 a4 55 ff ff      	call -0xaa5c
   62b68: 79 a7 30 f9 00 00 00 00      	ldxdw r7, [r10 - 0x6d0]
   62b70: 79 a1 28 f9 00 00 00 00      	ldxdw r1, [r10 - 0x6d8]
   62b78: 7b 1a b8 f6 00 00 00 00      	stxdw [r10 - 0x948], r1
   62b80: 71 a1 25 fa 00 00 00 00      	ldxb r1, [r10 - 0x5db]
   62b88: 55 01 59 00 02 00 00 00      	jne r1, 0x2, +0x59 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x380>
   62b90: 85 10 00 00 ae 37 00 00      	call 0x37ae
   62b98: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   62ba8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   62bb0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   62bb8: 07 01 00 00 f3 ff ff ff      	add64 r1, -0xd
   62bc0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   62bc8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   62bd0: 2d 21 6b 00 00 00 00 00      	jgt r1, r2, +0x6b <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x458>
   62bd8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   62be0: 15 04 6a 00 00 00 00 00      	jeq r4, 0x0, +0x6a <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x460>
   62be8: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   62bf8: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x130>
   62c00: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   62c08: 79 a3 b8 f6 00 00 00 00      	ldxdw r3, [r10 - 0x948]
   62c10: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   62c18: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   62c20: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   62c30: bd 21 1e 04 00 00 00 00      	jle r1, r2, +0x41e <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2250>
   62c38: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   62c48: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   62c50: 18 02 00 00 6c 5f 70 61 00 00 00 00 72 61 6d 73      	lddw r2, 0x736d617261705f6c
   62c60: 7b 21 05 00 00 00 00 00      	stxdw [r1 + 0x5], r2
   62c68: 18 02 00 00 67 6c 6f 62 00 00 00 00 61 6c 5f 70      	lddw r2, 0x705f6c61626f6c67
   62c78: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   62c80: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   62c88: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   62c90: 7a 07 18 00 0d 00 00 00      	stdw [r7 + 0x18], 0xd
   62c98: 7a 07 08 00 0d 00 00 00      	stdw [r7 + 0x8], 0xd
   62ca0: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   62ca8: 79 a1 c0 f6 00 00 00 00      	ldxdw r1, [r10 - 0x940]
   62cb0: 7b 71 10 00 00 00 00 00      	stxdw [r1 + 0x10], r7
   62cb8: 7b 31 08 00 00 00 00 00      	stxdw [r1 + 0x8], r3
   62cc0: 05 00 30 00 00 00 00 00      	ja +0x30 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x370>
   62cc8: 85 10 00 00 87 37 00 00      	call 0x3787
   62cd0: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   62ce0: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   62ce8: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   62cf0: 07 01 00 00 fb ff ff ff      	add64 r1, -0x5
   62cf8: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   62d00: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   62d08: 2d 21 10 00 00 00 00 00      	jgt r1, r2, +0x10 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2b8>
   62d10: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   62d18: 15 04 0f 00 00 00 00 00      	jeq r4, 0x0, +0xf <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2c0>
   62d20: 18 01 00 00 fb 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffb
   62d30: 15 02 10 00 00 00 00 00      	jeq r2, 0x0, +0x10 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2e0>
   62d38: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   62d40: bf 62 00 00 00 00 00 00      	mov64 r2, r6
   62d48: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   62d50: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   62d60: 2d 21 0f 00 00 00 00 00      	jgt r1, r2, +0xf <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x308>
   62d68: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   62d70: b7 02 00 00 05 00 00 00      	mov64 r2, 0x5
   62d78: 18 03 00 00 10 eb 09 00 00 00 00 00 00 00 00 00      	lddw r3, 0x9eb10
   62d88: 85 10 00 00 f8 5c 00 00      	call 0x5cf8
   62d90: 55 04 f1 ff 00 00 00 00      	jne r4, 0x0, -0xf <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x248>
   62d98: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   62da0: 18 01 00 00 fb 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffb
   62db0: 55 02 f0 ff 00 00 00 00      	jne r2, 0x0, -0x10 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x260>
   62db8: bf 62 00 00 00 00 00 00      	mov64 r2, r6
   62dc0: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   62dc8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   62dd8: bd 21 f1 ff 00 00 00 00      	jle r1, r2, -0xf <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x290>
   62de0: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   62df0: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   62df8: 72 01 04 00 72 00 00 00      	stb [r1 + 0x4], 0x72
   62e00: 62 01 00 00 70 61 79 65      	stw [r1 + 0x0], 0x65796170
   62e08: 79 92 00 00 00 00 00 00      	ldxdw r2, [r9 + 0x0]
   62e10: 7b 19 10 00 00 00 00 00      	stxdw [r9 + 0x10], r1
   62e18: 7a 09 18 00 05 00 00 00      	stdw [r9 + 0x18], 0x5
   62e20: 7a 09 08 00 05 00 00 00      	stdw [r9 + 0x8], 0x5
   62e28: 7a 09 00 00 01 00 00 00      	stdw [r9 + 0x0], 0x1
   62e30: 79 a1 c0 f6 00 00 00 00      	ldxdw r1, [r10 - 0x940]
   62e38: 7b 91 10 00 00 00 00 00      	stxdw [r1 + 0x10], r9
   62e40: 7b 61 08 00 00 00 00 00      	stxdw [r1 + 0x8], r6
   62e48: 62 01 00 00 02 00 00 00      	stw [r1 + 0x0], 0x2
   62e50: 95 00 00 00 00 00 00 00      	exit
   62e58: 7b 1a b0 f6 00 00 00 00      	stxdw [r10 - 0x950], r1
   62e60: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62e68: 07 01 00 00 28 fa ff ff      	add64 r1, -0x5d8
   62e70: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   62e78: 07 02 00 00 38 f9 ff ff      	add64 r2, -0x6c8
   62e80: b7 03 00 00 ed 00 00 00      	mov64 r3, 0xed
   62e88: 85 10 00 00 98 6a 00 00      	call 0x6a98
   62e90: 69 a1 26 fa 00 00 00 00      	ldxh r1, [r10 - 0x5da]
   62e98: 7b 1a a8 f6 00 00 00 00      	stxdw [r10 - 0x958], r1
   62ea0: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   62ea8: 15 01 16 00 00 00 00 00      	jeq r1, 0x0, +0x16 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x488>
   62eb0: 79 83 00 00 00 00 00 00      	ldxdw r3, [r8 + 0x0]
   62eb8: bf 32 00 00 00 00 00 00      	mov64 r2, r3
   62ec0: 07 02 00 00 30 00 00 00      	add64 r2, 0x30
   62ec8: 7b 28 00 00 00 00 00 00      	stxdw [r8 + 0x0], r2
   62ed0: bf 12 00 00 00 00 00 00      	mov64 r2, r1
   62ed8: 07 02 00 00 ff ff ff ff      	add64 r2, -0x1
   62ee0: 7b 28 08 00 00 00 00 00      	stxdw [r8 + 0x8], r2
   62ee8: 7b 3a a0 f6 00 00 00 00      	stxdw [r10 - 0x960], r3
   62ef0: 15 02 15 00 00 00 00 00      	jeq r2, 0x0, +0x15 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x4c8>
   62ef8: 07 01 00 00 fe ff ff ff      	add64 r1, -0x2
   62f00: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   62f08: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   62f10: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   62f18: 07 01 00 00 30 00 00 00      	add64 r1, 0x30
   62f20: 7b 18 00 00 00 00 00 00      	stxdw [r8 + 0x0], r1
   62f28: 05 00 15 00 00 00 00 00      	ja +0x15 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x500>
   62f30: 55 04 96 ff 00 00 00 00      	jne r4, 0x0, -0x6a <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x110>
   62f38: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   62f40: 18 01 00 00 f3 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff3
   62f50: 55 02 95 ff 00 00 00 00      	jne r2, 0x0, -0x6b <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x128>
   62f58: 05 00 95 ff 00 00 00 00      	ja -0x6b <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x130>
   62f60: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62f68: 07 01 00 00 f8 f8 ff ff      	add64 r1, -0x708
   62f70: b7 02 00 00 bd 0b 00 00      	mov64 r2, 0xbbd
   62f78: 85 10 00 00 1b 4a 00 00      	call 0x4a1b
   62f80: 79 a1 00 f9 00 00 00 00      	ldxdw r1, [r10 - 0x700]
   62f88: 79 a2 f8 f8 00 00 00 00      	ldxdw r2, [r10 - 0x708]
   62f90: 55 02 e5 00 02 00 00 00      	jne r2, 0x2, +0xe5 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xbe8>
   62f98: 7b 1a a0 f6 00 00 00 00      	stxdw [r10 - 0x960], r1
   62fa0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62fa8: 07 01 00 00 e8 f8 ff ff      	add64 r1, -0x718
   62fb0: b7 02 00 00 bd 0b 00 00      	mov64 r2, 0xbbd
   62fb8: 85 10 00 00 13 4a 00 00      	call 0x4a13
   62fc0: 79 a2 f0 f8 00 00 00 00      	ldxdw r2, [r10 - 0x710]
   62fc8: 79 a1 e8 f8 00 00 00 00      	ldxdw r1, [r10 - 0x718]
   62fd0: 55 01 b3 00 02 00 00 00      	jne r1, 0x2, +0xb3 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xa98>
   62fd8: 7b 2a 98 f6 00 00 00 00      	stxdw [r10 - 0x968], r2
   62fe0: 7b 2a 18 fb 00 00 00 00      	stxdw [r10 - 0x4e8], r2
   62fe8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   62ff0: 07 01 00 00 a0 fb ff ff      	add64 r1, -0x460
   62ff8: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   63000: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   63008: 85 10 00 00 5e 3d ff ff      	call -0xc2a2
   63010: 61 a1 a0 fb 00 00 00 00      	ldxw r1, [r10 - 0x460]
   63018: 55 01 21 00 02 00 00 00      	jne r1, 0x2, +0x21 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x650>
   63020: 79 a7 b0 fb 00 00 00 00      	ldxdw r7, [r10 - 0x450]
   63028: 79 a6 a8 fb 00 00 00 00      	ldxdw r6, [r10 - 0x458]
   63030: 85 10 00 00 1a 37 00 00      	call 0x371a
   63038: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   63048: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   63050: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   63058: 07 01 00 00 fc ff ff ff      	add64 r1, -0x4
   63060: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   63068: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   63070: 2d 21 91 00 00 00 00 00      	jgt r1, r2, +0x91 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xa28>
   63078: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   63080: 15 04 90 00 00 00 00 00      	jeq r4, 0x0, +0x90 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xa30>
   63088: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   63098: 15 02 91 00 00 00 00 00      	jeq r2, 0x0, +0x91 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xa50>
   630a0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   630a8: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   630b8: 15 06 90 00 01 00 00 00      	jeq r6, 0x1, +0x90 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xa68>
   630c0: bd 21 90 00 00 00 00 00      	jle r1, r2, +0x90 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xa70>
   630c8: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   630d8: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   630e0: 62 01 00 00 6d 69 6e 74      	stw [r1 + 0x0], 0x746e696d
   630e8: 79 72 00 00 00 00 00 00      	ldxdw r2, [r7 + 0x0]
   630f0: 7b 17 10 00 00 00 00 00      	stxdw [r7 + 0x10], r1
   630f8: 7a 07 18 00 04 00 00 00      	stdw [r7 + 0x18], 0x4
   63100: 7a 07 08 00 04 00 00 00      	stdw [r7 + 0x8], 0x4
   63108: 7a 07 00 00 01 00 00 00      	stdw [r7 + 0x0], 0x1
   63110: 79 a1 c0 f6 00 00 00 00      	ldxdw r1, [r10 - 0x940]
   63118: 7b 71 10 00 00 00 00 00      	stxdw [r1 + 0x10], r7
   63120: 05 00 a3 ff 00 00 00 00      	ja -0x5d <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x368>
   63128: 7b 6a 80 f6 00 00 00 00      	stxdw [r10 - 0x980], r6
   63130: 7b 9a 78 f6 00 00 00 00      	stxdw [r10 - 0x988], r9
   63138: 7b 7a 70 f6 00 00 00 00      	stxdw [r10 - 0x990], r7
   63140: 61 a2 a4 fb 00 00 00 00      	ldxw r2, [r10 - 0x45c]
   63148: 7b 2a 90 f6 00 00 00 00      	stxdw [r10 - 0x970], r2
   63150: 79 a6 a8 fb 00 00 00 00      	ldxdw r6, [r10 - 0x458]
   63158: 79 a9 b0 fb 00 00 00 00      	ldxdw r9, [r10 - 0x450]
   63160: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   63168: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63170: 07 01 00 00 40 fc ff ff      	add64 r1, -0x3c0
   63178: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   63180: 07 02 00 00 b8 fb ff ff      	add64 r2, -0x448
   63188: 7b 2a 88 f6 00 00 00 00      	stxdw [r10 - 0x978], r2
   63190: b7 03 00 00 40 00 00 00      	mov64 r3, 0x40
   63198: 85 10 00 00 36 6a 00 00      	call 0x6a36
   631a0: 7b 7a 58 f6 00 00 00 00      	stxdw [r10 - 0x9a8], r7
   631a8: 63 7a 20 fb 00 00 00 00      	stxw [r10 - 0x4e0], r7
   631b0: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   631b8: 7b 1a 20 fc 00 00 00 00      	stxdw [r10 - 0x3e0], r1
   631c0: 79 a1 08 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f8]
   631c8: 7b 1a 28 fc 00 00 00 00      	stxdw [r10 - 0x3d8], r1
   631d0: 79 a1 10 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f0]
   631d8: 7b 1a 30 fc 00 00 00 00      	stxdw [r10 - 0x3d0], r1
   631e0: 79 a1 18 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e8]
   631e8: 7b 1a 38 fc 00 00 00 00      	stxdw [r10 - 0x3c8], r1
   631f0: 7b 9a 60 f6 00 00 00 00      	stxdw [r10 - 0x9a0], r9
   631f8: 7b 9a 30 fb 00 00 00 00      	stxdw [r10 - 0x4d0], r9
   63200: 7b 6a 68 f6 00 00 00 00      	stxdw [r10 - 0x998], r6
   63208: 7b 6a 28 fb 00 00 00 00      	stxdw [r10 - 0x4d8], r6
   63210: 79 a1 90 f6 00 00 00 00      	ldxdw r1, [r10 - 0x970]
   63218: 63 1a 24 fb 00 00 00 00      	stxw [r10 - 0x4dc], r1
   63220: 79 a9 f8 fb 00 00 00 00      	ldxdw r9, [r10 - 0x408]
   63228: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63230: 07 01 00 00 38 fb ff ff      	add64 r1, -0x4c8
   63238: 79 a2 88 f6 00 00 00 00      	ldxdw r2, [r10 - 0x978]
   63240: b7 03 00 00 40 00 00 00      	mov64 r3, 0x40
   63248: 85 10 00 00 20 6a 00 00      	call 0x6a20
   63250: 79 a1 18 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e8]
   63258: 7b 1a 98 fb 00 00 00 00      	stxdw [r10 - 0x468], r1
   63260: 79 a1 10 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f0]
   63268: 7b 1a 90 fb 00 00 00 00      	stxdw [r10 - 0x470], r1
   63270: 79 a1 08 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3f8]
   63278: 7b 1a 88 fb 00 00 00 00      	stxdw [r10 - 0x478], r1
   63280: 79 a1 00 fc 00 00 00 00      	ldxdw r1, [r10 - 0x400]
   63288: 7b 1a 80 fb 00 00 00 00      	stxdw [r10 - 0x480], r1
   63290: 7b 9a 78 fb 00 00 00 00      	stxdw [r10 - 0x488], r9
   63298: 79 81 08 00 00 00 00 00      	ldxdw r1, [r8 + 0x8]
   632a0: 15 01 b3 00 00 00 00 00      	jeq r1, 0x0, +0xb3 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xd68>
   632a8: 79 82 00 00 00 00 00 00      	ldxdw r2, [r8 + 0x0]
   632b0: 7b 2a 80 fc 00 00 00 00      	stxdw [r10 - 0x380], r2
   632b8: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   632c0: 07 03 00 00 ff ff ff ff      	add64 r3, -0x1
   632c8: 7b 38 08 00 00 00 00 00      	stxdw [r8 + 0x8], r3
   632d0: bf 27 00 00 00 00 00 00      	mov64 r7, r2
   632d8: 07 07 00 00 30 00 00 00      	add64 r7, 0x30
   632e0: 7b 78 00 00 00 00 00 00      	stxdw [r8 + 0x0], r7
   632e8: 15 03 b6 00 00 00 00 00      	jeq r3, 0x0, +0xb6 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdc8>
   632f0: 7b 7a 88 fc 00 00 00 00      	stxdw [r10 - 0x378], r7
   632f8: 07 01 00 00 fe ff ff ff      	add64 r1, -0x2
   63300: 7b 18 08 00 00 00 00 00      	stxdw [r8 + 0x8], r1
   63308: 07 02 00 00 60 00 00 00      	add64 r2, 0x60
   63310: 7b 28 00 00 00 00 00 00      	stxdw [r8 + 0x0], r2
   63318: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63320: 07 01 00 00 e0 fc ff ff      	add64 r1, -0x320
   63328: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   63330: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   63338: 85 10 00 00 19 59 ff ff      	call -0xa6e7
   63340: 79 a3 e8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x318]
   63348: 79 a1 e0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x320]
   63350: 55 01 a4 00 02 00 00 00      	jne r1, 0x2, +0xa4 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xda0>
   63358: 7b 3a 88 f6 00 00 00 00      	stxdw [r10 - 0x978], r3
   63360: 7b 3a 90 fc 00 00 00 00      	stxdw [r10 - 0x370], r3
   63368: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63370: 07 01 00 00 a0 fc ff ff      	add64 r1, -0x360
   63378: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   63380: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   63388: 85 10 00 00 b2 39 ff ff      	call -0xc64e
   63390: 79 a3 a8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x358]
   63398: 79 a2 a0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x360]
   633a0: 15 02 09 00 02 00 00 00      	jeq r2, 0x2, +0x9 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x918>
   633a8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   633b0: 07 01 00 00 d8 f8 ff ff      	add64 r1, -0x728
   633b8: 18 04 00 00 12 b4 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9b412
   633c8: b7 05 00 00 0d 00 00 00      	mov64 r5, 0xd
   633d0: 85 10 00 00 fd 3e ff ff      	call -0xc103
   633d8: 79 a3 e0 f8 00 00 00 00      	ldxdw r3, [r10 - 0x720]
   633e0: 79 a1 d8 f8 00 00 00 00      	ldxdw r1, [r10 - 0x728]
   633e8: 55 01 91 00 02 00 00 00      	jne r1, 0x2, +0x91 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xda0>
   633f0: 7b 3a 50 f6 00 00 00 00      	stxdw [r10 - 0x9b0], r3
   633f8: 7b 3a 98 fc 00 00 00 00      	stxdw [r10 - 0x368], r3
   63400: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63408: 07 01 00 00 b8 fc ff ff      	add64 r1, -0x348
   63410: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   63418: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   63420: 85 10 00 00 0f 55 ff ff      	call -0xaaf1
   63428: 79 a8 c0 fc 00 00 00 00      	ldxdw r8, [r10 - 0x340]
   63430: 79 a2 b8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x348]
   63438: 15 02 0a 00 02 00 00 00      	jeq r2, 0x2, +0xa <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x9b8>
   63440: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63448: 07 01 00 00 c8 f8 ff ff      	add64 r1, -0x738
   63450: bf 83 00 00 00 00 00 00      	mov64 r3, r8
   63458: 18 04 00 00 28 b6 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9b628
   63468: b7 05 00 00 18 00 00 00      	mov64 r5, 0x18
   63470: 85 10 00 00 e9 3e ff ff      	call -0xc117
   63478: 79 a8 d0 f8 00 00 00 00      	ldxdw r8, [r10 - 0x730]
   63480: 79 a1 c8 f8 00 00 00 00      	ldxdw r1, [r10 - 0x738]
   63488: 55 01 b7 00 02 00 00 00      	jne r1, 0x2, +0xb7 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xf70>
   63490: 7b 8a b0 fc 00 00 00 00      	stxdw [r10 - 0x350], r8
   63498: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   634a0: 07 01 00 00 e0 fc ff ff      	add64 r1, -0x320
   634a8: 85 10 00 00 d7 52 00 00      	call 0x52d7
   634b0: 61 a1 e0 fc 00 00 00 00      	ldxw r1, [r10 - 0x320]
   634b8: 55 01 87 00 01 00 00 00      	jne r1, 0x1, +0x87 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xe20>
   634c0: 61 a3 e8 fc 00 00 00 00      	ldxw r3, [r10 - 0x318]
   634c8: 61 a2 e4 fc 00 00 00 00      	ldxw r2, [r10 - 0x31c]
   634d0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   634d8: 07 01 00 00 e8 f6 ff ff      	add64 r1, -0x918
   634e0: 85 10 00 00 bb 43 00 00      	call 0x43bb
   634e8: 79 a1 e8 f6 00 00 00 00      	ldxdw r1, [r10 - 0x918]
   634f0: 79 a2 f0 f6 00 00 00 00      	ldxdw r2, [r10 - 0x910]
   634f8: 05 00 7a 00 00 00 00 00      	ja +0x7a <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   63500: 55 04 70 ff 00 00 00 00      	jne r4, 0x0, -0x90 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x5b0>
   63508: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   63510: 18 01 00 00 fc 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ffc
   63520: 55 02 6f ff 00 00 00 00      	jne r2, 0x0, -0x91 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x5c8>
   63528: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   63538: 55 06 70 ff 01 00 00 00      	jne r6, 0x1, -0x90 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x5e8>
   63540: 2d 21 70 ff 00 00 00 00      	jgt r1, r2, -0x90 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x5f0>
   63548: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   63550: b7 02 00 00 04 00 00 00      	mov64 r2, 0x4
   63558: 18 03 00 00 10 eb 09 00 00 00 00 00 00 00 00 00      	lddw r3, 0x9eb10
   63568: 85 10 00 00 fc 5b 00 00      	call 0x5bfc
   63570: bf 16 00 00 00 00 00 00      	mov64 r6, r1
   63578: bf 27 00 00 00 00 00 00      	mov64 r7, r2
   63580: 85 10 00 00 70 36 00 00      	call 0x3670
   63588: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   63598: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   635a0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   635a8: 07 01 00 00 f7 ff ff ff      	add64 r1, -0x9
   635b0: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   635b8: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   635c0: 2d 21 19 00 00 00 00 00      	jgt r1, r2, +0x19 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xbb8>
   635c8: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   635d0: 15 04 18 00 00 00 00 00      	jeq r4, 0x0, +0x18 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xbc0>
   635d8: 18 01 00 00 f7 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff7
   635e8: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xb20>
   635f0: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   635f8: bf 64 00 00 00 00 00 00      	mov64 r4, r6
   63600: bf 42 00 00 00 00 00 00      	mov64 r2, r4
   63608: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   63610: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   63620: bf 73 00 00 00 00 00 00      	mov64 r3, r7
   63628: bd 21 58 03 00 00 00 00      	jle r1, r2, +0x358 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2618>
   63630: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   63640: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   63648: 18 02 00 00 73 6f 6c 5f 00 00 00 00 76 61 75 6c      	lddw r2, 0x6c7561765f6c6f73
   63658: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   63660: 72 01 08 00 74 00 00 00      	stb [r1 + 0x8], 0x74
   63668: 79 32 00 00 00 00 00 00      	ldxdw r2, [r3 + 0x0]
   63670: 7b 13 10 00 00 00 00 00      	stxdw [r3 + 0x10], r1
   63678: 7a 03 18 00 09 00 00 00      	stdw [r3 + 0x18], 0x9
   63680: 7a 03 08 00 09 00 00 00      	stdw [r3 + 0x8], 0x9
   63688: 05 00 2b 00 00 00 00 00      	ja +0x2b <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xd10>
   63690: 55 04 e8 ff 00 00 00 00      	jne r4, 0x0, -0x18 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xb00>
   63698: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   636a0: 18 01 00 00 f7 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff7
   636b0: 55 02 e7 ff 00 00 00 00      	jne r2, 0x0, -0x19 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xb18>
   636b8: 05 00 e7 ff 00 00 00 00      	ja -0x19 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xb20>
   636c0: bf 26 00 00 00 00 00 00      	mov64 r6, r2
   636c8: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   636d0: 85 10 00 00 46 36 00 00      	call 0x3646
   636d8: 18 01 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300000000
   636e8: 79 12 00 00 00 00 00 00      	ldxdw r2, [r1 + 0x0]
   636f0: bf 21 00 00 00 00 00 00      	mov64 r1, r2
   636f8: 07 01 00 00 f2 ff ff ff      	add64 r1, -0xe
   63700: b7 03 00 00 00 00 00 00      	mov64 r3, 0x0
   63708: b7 04 00 00 01 00 00 00      	mov64 r4, 0x1
   63710: 2d 21 1f 00 00 00 00 00      	jgt r1, r2, +0x1f <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xd38>
   63718: b7 04 00 00 00 00 00 00      	mov64 r4, 0x0
   63720: 15 04 1e 00 00 00 00 00      	jeq r4, 0x0, +0x1e <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xd40>
   63728: 18 01 00 00 f2 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff2
   63738: 15 02 01 00 00 00 00 00      	jeq r2, 0x0, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xc70>
   63740: bf 31 00 00 00 00 00 00      	mov64 r1, r3
   63748: bf 64 00 00 00 00 00 00      	mov64 r4, r6
   63750: bf 42 00 00 00 00 00 00      	mov64 r2, r4
   63758: 57 02 00 00 01 00 00 00      	and64 r2, 0x1
   63760: 18 02 00 00 07 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000007
   63770: bf 73 00 00 00 00 00 00      	mov64 r3, r7
   63778: bd 21 33 03 00 00 00 00      	jle r1, r2, +0x333 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2640>
   63780: 18 02 00 00 00 00 00 00 00 00 00 00 03 00 00 00      	lddw r2, 0x300000000
   63790: 7b 12 00 00 00 00 00 00      	stxdw [r2 + 0x0], r1
   63798: 18 02 00 00 75 74 68 6f 00 00 00 00 72 69 74 79      	lddw r2, 0x797469726f687475
   637a8: 7b 21 06 00 00 00 00 00      	stxdw [r1 + 0x6], r2
   637b0: 18 02 00 00 6d 69 6e 74 00 00 00 00 5f 61 75 74      	lddw r2, 0x7475615f746e696d
   637c0: 7b 21 00 00 00 00 00 00      	stxdw [r1 + 0x0], r2
   637c8: 79 32 00 00 00 00 00 00      	ldxdw r2, [r3 + 0x0]
   637d0: 7b 13 10 00 00 00 00 00      	stxdw [r3 + 0x10], r1
   637d8: 7a 03 18 00 0e 00 00 00      	stdw [r3 + 0x18], 0xe
   637e0: 7a 03 08 00 0e 00 00 00      	stdw [r3 + 0x8], 0xe
   637e8: 7a 03 00 00 01 00 00 00      	stdw [r3 + 0x0], 0x1
   637f0: 79 a1 c0 f6 00 00 00 00      	ldxdw r1, [r10 - 0x940]
   637f8: 7b 31 10 00 00 00 00 00      	stxdw [r1 + 0x10], r3
   63800: 7b 41 08 00 00 00 00 00      	stxdw [r1 + 0x8], r4
   63808: 05 00 c7 fe 00 00 00 00      	ja -0x139 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x370>
   63810: 55 04 e2 ff 00 00 00 00      	jne r4, 0x0, -0x1e <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xc50>
   63818: bf 13 00 00 00 00 00 00      	mov64 r3, r1
   63820: 18 01 00 00 f2 7f 00 00 00 00 00 00 03 00 00 00      	lddw r1, 0x300007ff2
   63830: 55 02 e1 ff 00 00 00 00      	jne r2, 0x0, -0x1f <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xc68>
   63838: 05 00 e1 ff 00 00 00 00      	ja -0x1f <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xc70>
   63840: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63848: 07 01 00 00 c8 f6 ff ff      	add64 r1, -0x938
   63850: b7 02 00 00 bd 0b 00 00      	mov64 r2, 0xbbd
   63858: 85 10 00 00 ff 48 00 00      	call 0x48ff
   63860: 79 a1 c8 f6 00 00 00 00      	ldxdw r1, [r10 - 0x938]
   63868: 79 a2 d0 f6 00 00 00 00      	ldxdw r2, [r10 - 0x930]
   63870: 05 00 0b 00 00 00 00 00      	ja +0xb <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   63878: 79 a2 c0 f6 00 00 00 00      	ldxdw r2, [r10 - 0x940]
   63880: 7b 32 10 00 00 00 00 00      	stxdw [r2 + 0x10], r3
   63888: 7b 12 08 00 00 00 00 00      	stxdw [r2 + 0x8], r1
   63890: 62 02 00 00 02 00 00 00      	stw [r2 + 0x0], 0x2
   63898: 05 00 b6 fe 00 00 00 00      	ja -0x14a <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x378>
   638a0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   638a8: 07 01 00 00 d8 f6 ff ff      	add64 r1, -0x928
   638b0: b7 02 00 00 bd 0b 00 00      	mov64 r2, 0xbbd
   638b8: 85 10 00 00 f3 48 00 00      	call 0x48f3
   638c0: 79 a1 d8 f6 00 00 00 00      	ldxdw r1, [r10 - 0x928]
   638c8: 79 a2 e0 f6 00 00 00 00      	ldxdw r2, [r10 - 0x920]
   638d0: 79 a3 c0 f6 00 00 00 00      	ldxdw r3, [r10 - 0x940]
   638d8: 7b 23 10 00 00 00 00 00      	stxdw [r3 + 0x10], r2
   638e0: 7b 13 08 00 00 00 00 00      	stxdw [r3 + 0x8], r1
   638e8: 62 03 00 00 02 00 00 00      	stw [r3 + 0x0], 0x2
   638f0: 05 00 ab fe 00 00 00 00      	ja -0x155 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x378>
   638f8: 79 a1 ec fc 00 00 00 00      	ldxdw r1, [r10 - 0x314]
   63900: 7b 1a cc fc 00 00 00 00      	stxdw [r10 - 0x334], r1
   63908: 79 a1 f4 fc 00 00 00 00      	ldxdw r1, [r10 - 0x30c]
   63910: 7b 1a d4 fc 00 00 00 00      	stxdw [r10 - 0x32c], r1
   63918: 61 a1 fc fc 00 00 00 00      	ldxw r1, [r10 - 0x304]
   63920: 63 1a dc fc 00 00 00 00      	stxw [r10 - 0x324], r1
   63928: 61 a1 e8 fc 00 00 00 00      	ldxw r1, [r10 - 0x318]
   63930: 63 1a c8 fc 00 00 00 00      	stxw [r10 - 0x338], r1
   63938: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63940: 07 01 00 00 98 fc ff ff      	add64 r1, -0x368
   63948: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
   63950: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63958: 07 01 00 00 90 fc ff ff      	add64 r1, -0x370
   63960: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   63968: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63970: 07 01 00 00 20 fb ff ff      	add64 r1, -0x4e0
   63978: 7b 1a f8 fe 00 00 00 00      	stxdw [r10 - 0x108], r1
   63980: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63988: 07 01 00 00 18 fb ff ff      	add64 r1, -0x4e8
   63990: 7b 1a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r1
   63998: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   639a0: 07 01 00 00 10 f9 ff ff      	add64 r1, -0x6f0
   639a8: 7b 1a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r1
   639b0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   639b8: 07 01 00 00 b0 fc ff ff      	add64 r1, -0x350
   639c0: 7b 1a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r1
   639c8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   639d0: 07 01 00 00 80 fc ff ff      	add64 r1, -0x380
   639d8: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   639e0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   639e8: 07 01 00 00 e0 fc ff ff      	add64 r1, -0x320
   639f0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   639f8: 07 02 00 00 d8 fe ff ff      	add64 r2, -0x128
   63a00: 85 10 00 00 44 03 00 00      	call 0x344
   63a08: 79 a3 e8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x318]
   63a10: 79 a2 e0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x320]
   63a18: 61 a1 90 fd 00 00 00 00      	ldxw r1, [r10 - 0x270]
   63a20: 55 01 07 00 02 00 00 00      	jne r1, 0x2, +0x7 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xf88>
   63a28: 79 a1 c0 f6 00 00 00 00      	ldxdw r1, [r10 - 0x940]
   63a30: 7b 31 10 00 00 00 00 00      	stxdw [r1 + 0x10], r3
   63a38: 7b 21 08 00 00 00 00 00      	stxdw [r1 + 0x8], r2
   63a40: 05 00 80 fe 00 00 00 00      	ja -0x180 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x370>
   63a48: 79 a2 c0 f6 00 00 00 00      	ldxdw r2, [r10 - 0x940]
   63a50: 7b 82 10 00 00 00 00 00      	stxdw [r2 + 0x10], r8
   63a58: 05 00 c5 ff 00 00 00 00      	ja -0x3b <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdb0>
   63a60: 7b 1a 38 f6 00 00 00 00      	stxdw [r10 - 0x9c8], r1
   63a68: 7b 3a 40 f6 00 00 00 00      	stxdw [r10 - 0x9c0], r3
   63a70: 7b 2a 48 f6 00 00 00 00      	stxdw [r10 - 0x9b8], r2
   63a78: 79 a1 f8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x308]
   63a80: 7b 1a 70 fe 00 00 00 00      	stxdw [r10 - 0x190], r1
   63a88: 79 a1 f0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x310]
   63a90: 7b 1a 68 fe 00 00 00 00      	stxdw [r10 - 0x198], r1
   63a98: 79 a6 00 fd 00 00 00 00      	ldxdw r6, [r10 - 0x300]
   63aa0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63aa8: 07 01 00 00 e0 fd ff ff      	add64 r1, -0x220
   63ab0: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   63ab8: 07 02 00 00 08 fd ff ff      	add64 r2, -0x2f8
   63ac0: b7 03 00 00 88 00 00 00      	mov64 r3, 0x88
   63ac8: 85 10 00 00 10 69 00 00      	call 0x6910
   63ad0: 79 a1 94 fd 00 00 00 00      	ldxdw r1, [r10 - 0x26c]
   63ad8: 7b 1a b8 fd 00 00 00 00      	stxdw [r10 - 0x248], r1
   63ae0: 79 a1 9c fd 00 00 00 00      	ldxdw r1, [r10 - 0x264]
   63ae8: 7b 1a c0 fd 00 00 00 00      	stxdw [r10 - 0x240], r1
   63af0: 79 a1 a4 fd 00 00 00 00      	ldxdw r1, [r10 - 0x25c]
   63af8: 7b 1a c8 fd 00 00 00 00      	stxdw [r10 - 0x238], r1
   63b00: 79 a1 ac fd 00 00 00 00      	ldxdw r1, [r10 - 0x254]
   63b08: 7b 1a d0 fd 00 00 00 00      	stxdw [r10 - 0x230], r1
   63b10: 61 a1 b4 fd 00 00 00 00      	ldxw r1, [r10 - 0x24c]
   63b18: 63 1a d8 fd 00 00 00 00      	stxw [r10 - 0x228], r1
   63b20: 71 61 29 00 00 00 00 00      	ldxb r1, [r6 + 0x29]
   63b28: 15 01 27 00 00 00 00 00      	jeq r1, 0x0, +0x27 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1190>
   63b30: 7b 8a 20 f6 00 00 00 00      	stxdw [r10 - 0x9e0], r8
   63b38: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   63b40: 07 08 00 00 d8 fe ff ff      	add64 r8, -0x128
   63b48: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   63b50: bf 62 00 00 00 00 00 00      	mov64 r2, r6
   63b58: 85 10 00 00 26 52 ff ff      	call -0xadda
   63b60: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   63b68: 85 10 00 00 75 54 00 00      	call 0x5475
   63b70: 7b 0a 30 f6 00 00 00 00      	stxdw [r10 - 0x9d0], r0
   63b78: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   63b80: 07 08 00 00 e0 fc ff ff      	add64 r8, -0x320
   63b88: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   63b90: 7b 6a 28 f6 00 00 00 00      	stxdw [r10 - 0x9d8], r6
   63b98: bf 62 00 00 00 00 00 00      	mov64 r2, r6
   63ba0: 85 10 00 00 1d 52 ff ff      	call -0xade3
   63ba8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63bb0: 07 01 00 00 b8 fe ff ff      	add64 r1, -0x148
   63bb8: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   63bc0: 85 10 00 00 83 54 00 00      	call 0x5483
   63bc8: 61 a1 b8 fe 00 00 00 00      	ldxw r1, [r10 - 0x148]
   63bd0: 55 01 21 00 01 00 00 00      	jne r1, 0x1, +0x21 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1208>
   63bd8: 61 a3 c0 fe 00 00 00 00      	ldxw r3, [r10 - 0x140]
   63be0: 61 a2 bc fe 00 00 00 00      	ldxw r2, [r10 - 0x144]
   63be8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63bf0: 07 01 00 00 f8 f6 ff ff      	add64 r1, -0x908
   63bf8: 85 10 00 00 d8 42 00 00      	call 0x42d8
   63c00: 79 a1 f8 f6 00 00 00 00      	ldxdw r1, [r10 - 0x908]
   63c08: 79 a2 00 f7 00 00 00 00      	ldxdw r2, [r10 - 0x900]
   63c10: 79 a3 c0 f6 00 00 00 00      	ldxdw r3, [r10 - 0x940]
   63c18: 7b 23 10 00 00 00 00 00      	stxdw [r3 + 0x10], r2
   63c20: 7b 13 08 00 00 00 00 00      	stxdw [r3 + 0x8], r1
   63c28: 62 03 00 00 02 00 00 00      	stw [r3 + 0x0], 0x2
   63c30: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63c38: 07 01 00 00 e0 fc ff ff      	add64 r1, -0x320
   63c40: 85 10 00 00 f8 4d ff ff      	call -0xb208
   63c48: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63c50: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   63c58: 85 10 00 00 f5 4d ff ff      	call -0xb20b
   63c60: 05 00 3d fe 00 00 00 00      	ja -0x1c3 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x378>
   63c68: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63c70: 07 01 00 00 b8 f8 ff ff      	add64 r1, -0x748
   63c78: b7 02 00 00 d0 07 00 00      	mov64 r2, 0x7d0
   63c80: 85 10 00 00 7a 48 00 00      	call 0x487a
   63c88: 79 a3 c0 f8 00 00 00 00      	ldxdw r3, [r10 - 0x740]
   63c90: 79 a2 b8 f8 00 00 00 00      	ldxdw r2, [r10 - 0x748]
   63c98: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63ca0: 07 01 00 00 a8 f8 ff ff      	add64 r1, -0x758
   63ca8: 18 04 00 00 c4 b3 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9b3c4
   63cb8: b7 05 00 00 12 00 00 00      	mov64 r5, 0x12
   63cc0: 85 10 00 00 df 3d ff ff      	call -0xc221
   63cc8: 79 a1 a8 f8 00 00 00 00      	ldxdw r1, [r10 - 0x758]
   63cd0: 79 a2 b0 f8 00 00 00 00      	ldxdw r2, [r10 - 0x750]
   63cd8: 05 00 7e ff 00 00 00 00      	ja -0x82 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   63ce0: 79 a3 c0 fe 00 00 00 00      	ldxdw r3, [r10 - 0x140]
   63ce8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63cf0: 07 01 00 00 c8 fc ff ff      	add64 r1, -0x338
   63cf8: 79 a2 30 f6 00 00 00 00      	ldxdw r2, [r10 - 0x9d0]
   63d00: 85 10 00 00 14 52 00 00      	call 0x5214
   63d08: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   63d10: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63d18: 07 01 00 00 e0 fc ff ff      	add64 r1, -0x320
   63d20: 85 10 00 00 dc 4d ff ff      	call -0xb224
   63d28: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63d30: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   63d38: 85 10 00 00 d9 4d ff ff      	call -0xb227
   63d40: 15 08 0d 00 00 00 00 00      	jeq r8, 0x0, +0xd <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x12d8>
   63d48: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63d50: 07 01 00 00 e0 fc ff ff      	add64 r1, -0x320
   63d58: 85 10 00 00 c1 51 00 00      	call 0x51c1
   63d60: 61 a1 e0 fc 00 00 00 00      	ldxw r1, [r10 - 0x320]
   63d68: 55 01 17 00 01 00 00 00      	jne r1, 0x1, +0x17 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1350>
   63d70: 61 a3 e8 fc 00 00 00 00      	ldxw r3, [r10 - 0x318]
   63d78: 61 a2 e4 fc 00 00 00 00      	ldxw r2, [r10 - 0x31c]
   63d80: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63d88: 07 01 00 00 08 f7 ff ff      	add64 r1, -0x8f8
   63d90: 85 10 00 00 a5 42 00 00      	call 0x42a5
   63d98: 79 a1 08 f7 00 00 00 00      	ldxdw r1, [r10 - 0x8f8]
   63da0: 79 a2 10 f7 00 00 00 00      	ldxdw r2, [r10 - 0x8f0]
   63da8: 05 00 64 ff 00 00 00 00      	ja -0x9c <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   63db0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63db8: 07 01 00 00 98 f8 ff ff      	add64 r1, -0x768
   63dc0: b7 02 00 00 d5 07 00 00      	mov64 r2, 0x7d5
   63dc8: 85 10 00 00 51 48 00 00      	call 0x4851
   63dd0: 79 a3 a0 f8 00 00 00 00      	ldxdw r3, [r10 - 0x760]
   63dd8: 79 a2 98 f8 00 00 00 00      	ldxdw r2, [r10 - 0x768]
   63de0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63de8: 07 01 00 00 88 f8 ff ff      	add64 r1, -0x778
   63df0: 18 04 00 00 c4 b3 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9b3c4
   63e00: b7 05 00 00 12 00 00 00      	mov64 r5, 0x12
   63e08: 85 10 00 00 b6 3d ff ff      	call -0xc24a
   63e10: 79 a1 88 f8 00 00 00 00      	ldxdw r1, [r10 - 0x778]
   63e18: 79 a2 90 f8 00 00 00 00      	ldxdw r2, [r10 - 0x770]
   63e20: 05 00 55 ff 00 00 00 00      	ja -0xab <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   63e28: 79 a1 ec fc 00 00 00 00      	ldxdw r1, [r10 - 0x314]
   63e30: 7b 1a 7c fe 00 00 00 00      	stxdw [r10 - 0x184], r1
   63e38: 79 a1 f4 fc 00 00 00 00      	ldxdw r1, [r10 - 0x30c]
   63e40: 7b 1a 84 fe 00 00 00 00      	stxdw [r10 - 0x17c], r1
   63e48: 61 a1 fc fc 00 00 00 00      	ldxw r1, [r10 - 0x304]
   63e50: 63 1a 8c fe 00 00 00 00      	stxw [r10 - 0x174], r1
   63e58: 61 a1 e8 fc 00 00 00 00      	ldxw r1, [r10 - 0x318]
   63e60: 63 1a 78 fe 00 00 00 00      	stxw [r10 - 0x188], r1
   63e68: 79 91 00 00 00 00 00 00      	ldxdw r1, [r9 + 0x0]
   63e70: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   63e78: 7b 2a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r2
   63e80: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   63e88: 7b 2a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r2
   63e90: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   63e98: 7b 2a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r2
   63ea0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63ea8: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   63eb0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63eb8: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   63ec0: 7b 1a c8 fe 00 00 00 00      	stxdw [r10 - 0x138], r1
   63ec8: 18 01 00 00 35 b4 09 00 00 00 00 00 00 00 00 00      	lddw r1, 0x9b435
   63ed8: 7b 1a b8 fe 00 00 00 00      	stxdw [r10 - 0x148], r1
   63ee0: 7a 0a d0 fe 20 00 00 00      	stdw [r10 - 0x130], 0x20
   63ee8: 7a 0a c0 fe 0c 00 00 00      	stdw [r10 - 0x140], 0xc
   63ef0: 79 a3 08 f9 00 00 00 00      	ldxdw r3, [r10 - 0x6f8]
   63ef8: 72 0a ff ff ff 00 00 00      	stb [r10 - 0x1], 0xff
   63f00: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   63f08: 07 01 00 00 b8 fe ff ff      	add64 r1, -0x148
   63f10: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   63f18: 07 04 00 00 e0 fc ff ff      	add64 r4, -0x320
   63f20: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   63f28: 07 05 00 00 ff ff ff ff      	add64 r5, -0x1
   63f30: b7 02 00 00 02 00 00 00      	mov64 r2, 0x2
   63f38: 85 10 00 00 ff ff ff ff      	call -0x1
   63f40: 55 00 1a 02 00 00 00 00      	jne r0, 0x0, +0x21a <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2540>
   63f48: 79 a1 f8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x308]
   63f50: 7b 1a a8 fe 00 00 00 00      	stxdw [r10 - 0x158], r1
   63f58: 79 a1 f0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x310]
   63f60: 7b 1a a0 fe 00 00 00 00      	stxdw [r10 - 0x160], r1
   63f68: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   63f70: 7b 1a 98 fe 00 00 00 00      	stxdw [r10 - 0x168], r1
   63f78: 79 a1 e0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x320]
   63f80: 7b 1a 90 fe 00 00 00 00      	stxdw [r10 - 0x170], r1
   63f88: 71 a1 ff ff 00 00 00 00      	ldxb r1, [r10 - 0x1]
   63f90: 73 1a b7 fe 00 00 00 00      	stxb [r10 - 0x149], r1
   63f98: 79 a2 80 f6 00 00 00 00      	ldxdw r2, [r10 - 0x980]
   63fa0: 73 12 03 00 00 00 00 00      	stxb [r2 + 0x3], r1
   63fa8: 79 71 00 00 00 00 00 00      	ldxdw r1, [r7 + 0x0]
   63fb0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   63fb8: 7b 2a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r2
   63fc0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   63fc8: 7b 2a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r2
   63fd0: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   63fd8: 7b 2a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r2
   63fe0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   63fe8: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   63ff0: 79 a2 90 fe 00 00 00 00      	ldxdw r2, [r10 - 0x170]
   63ff8: 5d 21 0a 00 00 00 00 00      	jne r1, r2, +0xa <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1578>
   64000: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
   64008: 79 a2 e8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x318]
   64010: 5d 12 07 00 00 00 00 00      	jne r2, r1, +0x7 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1578>
   64018: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   64020: 79 a2 f0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x310]
   64028: 5d 12 04 00 00 00 00 00      	jne r2, r1, +0x4 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1578>
   64030: b7 01 00 00 00 00 00 00      	mov64 r1, 0x0
   64038: 79 a2 a8 fe 00 00 00 00      	ldxdw r2, [r10 - 0x158]
   64040: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   64048: 1d 23 01 00 00 00 00 00      	jeq r3, r2, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1580>
   64050: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   64058: 15 01 27 00 00 00 00 00      	jeq r1, 0x0, +0x27 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x16c0>
   64060: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64068: 07 01 00 00 78 f8 ff ff      	add64 r1, -0x788
   64070: b7 02 00 00 d6 07 00 00      	mov64 r2, 0x7d6
   64078: 85 10 00 00 fb 47 00 00      	call 0x47fb
   64080: 79 a3 80 f8 00 00 00 00      	ldxdw r3, [r10 - 0x780]
   64088: 79 a2 78 f8 00 00 00 00      	ldxdw r2, [r10 - 0x788]
   64090: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64098: 07 01 00 00 68 f8 ff ff      	add64 r1, -0x798
   640a0: 18 04 00 00 b8 b3 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9b3b8
   640b0: b7 05 00 00 0c 00 00 00      	mov64 r5, 0xc
   640b8: 85 10 00 00 60 3d ff ff      	call -0xc2a0
   640c0: 79 a3 70 f8 00 00 00 00      	ldxdw r3, [r10 - 0x790]
   640c8: 79 a2 68 f8 00 00 00 00      	ldxdw r2, [r10 - 0x798]
   640d0: 79 71 00 00 00 00 00 00      	ldxdw r1, [r7 + 0x0]
   640d8: 79 14 18 00 00 00 00 00      	ldxdw r4, [r1 + 0x18]
   640e0: 7b 4a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r4
   640e8: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   640f0: 7b 4a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r4
   640f8: 79 14 08 00 00 00 00 00      	ldxdw r4, [r1 + 0x8]
   64100: 7b 4a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r4
   64108: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64110: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   64118: 79 a1 90 fe 00 00 00 00      	ldxdw r1, [r10 - 0x170]
   64120: 7b 1a 00 fd 00 00 00 00      	stxdw [r10 - 0x300], r1
   64128: 79 a1 98 fe 00 00 00 00      	ldxdw r1, [r10 - 0x168]
   64130: 7b 1a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r1
   64138: 79 a1 a0 fe 00 00 00 00      	ldxdw r1, [r10 - 0x160]
   64140: 7b 1a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r1
   64148: 79 a1 a8 fe 00 00 00 00      	ldxdw r1, [r10 - 0x158]
   64150: 7b 1a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r1
   64158: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64160: 07 01 00 00 58 f8 ff ff      	add64 r1, -0x7a8
   64168: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64170: 07 04 00 00 e0 fc ff ff      	add64 r4, -0x320
   64178: 85 10 00 00 42 42 00 00      	call 0x4242
   64180: 79 a1 58 f8 00 00 00 00      	ldxdw r1, [r10 - 0x7a8]
   64188: 79 a2 60 f8 00 00 00 00      	ldxdw r2, [r10 - 0x7a0]
   64190: 05 00 e7 fe 00 00 00 00      	ja -0x119 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   64198: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   641a0: 07 01 00 00 08 f9 ff ff      	add64 r1, -0x6f8
   641a8: 7b 1a 08 ff 00 00 00 00      	stxdw [r10 - 0xf8], r1
   641b0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   641b8: 07 01 00 00 b7 fe ff ff      	add64 r1, -0x149
   641c0: 7b 1a 00 ff 00 00 00 00      	stxdw [r10 - 0x100], r1
   641c8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   641d0: 07 01 00 00 20 fb ff ff      	add64 r1, -0x4e0
   641d8: 7b 1a f8 fe 00 00 00 00      	stxdw [r10 - 0x108], r1
   641e0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   641e8: 07 01 00 00 90 fc ff ff      	add64 r1, -0x370
   641f0: 7b 1a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r1
   641f8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64200: 07 01 00 00 10 f9 ff ff      	add64 r1, -0x6f0
   64208: 7b 1a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r1
   64210: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64218: 07 01 00 00 78 fe ff ff      	add64 r1, -0x188
   64220: 7b 1a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r1
   64228: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64230: 07 01 00 00 88 fc ff ff      	add64 r1, -0x378
   64238: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   64240: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64248: 07 01 00 00 e0 fc ff ff      	add64 r1, -0x320
   64250: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   64258: 07 02 00 00 d8 fe ff ff      	add64 r2, -0x128
   64260: 85 10 00 00 7d 05 00 00      	call 0x57d
   64268: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   64270: 7b 1a 30 f6 00 00 00 00      	stxdw [r10 - 0x9d0], r1
   64278: 79 a6 e0 fc 00 00 00 00      	ldxdw r6, [r10 - 0x320]
   64280: 71 a1 49 fd 00 00 00 00      	ldxb r1, [r10 - 0x2b7]
   64288: bf 17 00 00 00 00 00 00      	mov64 r7, r1
   64290: 55 01 04 00 02 00 00 00      	jne r1, 0x2, +0x4 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x17e0>
   64298: 79 a1 c0 f6 00 00 00 00      	ldxdw r1, [r10 - 0x940]
   642a0: 79 a2 30 f6 00 00 00 00      	ldxdw r2, [r10 - 0x9d0]
   642a8: 7b 21 10 00 00 00 00 00      	stxdw [r1 + 0x10], r2
   642b0: 05 00 71 fd 00 00 00 00      	ja -0x28f <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x368>
   642b8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   642c0: 07 01 00 00 18 ff ff ff      	add64 r1, -0xe8
   642c8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   642d0: 07 02 00 00 f0 fc ff ff      	add64 r2, -0x310
   642d8: b7 03 00 00 59 00 00 00      	mov64 r3, 0x59
   642e0: 85 10 00 00 0d 68 00 00      	call 0x680d
   642e8: 61 a1 4a fd 00 00 00 00      	ldxw r1, [r10 - 0x2b6]
   642f0: 63 1a 10 ff 00 00 00 00      	stxw [r10 - 0xf0], r1
   642f8: 69 a1 4e fd 00 00 00 00      	ldxh r1, [r10 - 0x2b2]
   64300: 6b 1a 14 ff 00 00 00 00      	stxh [r10 - 0xec], r1
   64308: 71 61 29 00 00 00 00 00      	ldxb r1, [r6 + 0x29]
   64310: 15 01 1b 00 00 00 00 00      	jeq r1, 0x0, +0x1b <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1918>
   64318: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   64320: 07 08 00 00 d8 fe ff ff      	add64 r8, -0x128
   64328: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   64330: bf 62 00 00 00 00 00 00      	mov64 r2, r6
   64338: 85 10 00 00 2a 51 ff ff      	call -0xaed6
   64340: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   64348: 85 10 00 00 79 53 00 00      	call 0x5379
   64350: 7b 0a 18 f6 00 00 00 00      	stxdw [r10 - 0x9e8], r0
   64358: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   64360: 07 08 00 00 e0 fc ff ff      	add64 r8, -0x320
   64368: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   64370: bf 62 00 00 00 00 00 00      	mov64 r2, r6
   64378: 85 10 00 00 22 51 ff ff      	call -0xaede
   64380: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64388: 07 01 00 00 b8 fe ff ff      	add64 r1, -0x148
   64390: bf 82 00 00 00 00 00 00      	mov64 r2, r8
   64398: 85 10 00 00 88 53 00 00      	call 0x5388
   643a0: 61 a1 b8 fe 00 00 00 00      	ldxw r1, [r10 - 0x148]
   643a8: 55 01 17 00 01 00 00 00      	jne r1, 0x1, +0x17 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1990>
   643b0: 61 a3 c0 fe 00 00 00 00      	ldxw r3, [r10 - 0x140]
   643b8: 61 a2 bc fe 00 00 00 00      	ldxw r2, [r10 - 0x144]
   643c0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   643c8: 07 01 00 00 18 f7 ff ff      	add64 r1, -0x8e8
   643d0: 85 10 00 00 dd 41 00 00      	call 0x41dd
   643d8: 79 a1 18 f7 00 00 00 00      	ldxdw r1, [r10 - 0x8e8]
   643e0: 79 a2 20 f7 00 00 00 00      	ldxdw r2, [r10 - 0x8e0]
   643e8: 05 00 04 ff 00 00 00 00      	ja -0xfc <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1138>
   643f0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   643f8: 07 01 00 00 48 f8 ff ff      	add64 r1, -0x7b8
   64400: b7 02 00 00 d0 07 00 00      	mov64 r2, 0x7d0
   64408: 85 10 00 00 89 47 00 00      	call 0x4789
   64410: 79 a3 50 f8 00 00 00 00      	ldxdw r3, [r10 - 0x7b0]
   64418: 79 a2 48 f8 00 00 00 00      	ldxdw r2, [r10 - 0x7b8]
   64420: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64428: 07 01 00 00 38 f8 ff ff      	add64 r1, -0x7c8
   64430: 18 04 00 00 b8 b3 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9b3b8
   64440: b7 05 00 00 0c 00 00 00      	mov64 r5, 0xc
   64448: 85 10 00 00 ee 3c ff ff      	call -0xc312
   64450: 79 a1 38 f8 00 00 00 00      	ldxdw r1, [r10 - 0x7c8]
   64458: 79 a2 40 f8 00 00 00 00      	ldxdw r2, [r10 - 0x7c0]
   64460: 05 00 8d fe 00 00 00 00      	ja -0x173 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   64468: 79 a3 c0 fe 00 00 00 00      	ldxdw r3, [r10 - 0x140]
   64470: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64478: 07 01 00 00 78 fe ff ff      	add64 r1, -0x188
   64480: 79 a2 18 f6 00 00 00 00      	ldxdw r2, [r10 - 0x9e8]
   64488: 85 10 00 00 23 51 00 00      	call 0x5123
   64490: bf 08 00 00 00 00 00 00      	mov64 r8, r0
   64498: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   644a0: 07 01 00 00 e0 fc ff ff      	add64 r1, -0x320
   644a8: 85 10 00 00 eb 4c ff ff      	call -0xb315
   644b0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   644b8: 07 01 00 00 d8 fe ff ff      	add64 r1, -0x128
   644c0: 85 10 00 00 e8 4c ff ff      	call -0xb318
   644c8: 15 08 31 00 00 00 00 00      	jeq r8, 0x0, +0x31 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1b80>
   644d0: 18 01 00 00 f0 ea 09 00 00 00 00 00 00 00 00 00      	lddw r1, 0x9eaf0
   644e0: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   644e8: 7b 2a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r2
   644f0: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   644f8: 7b 2a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r2
   64500: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   64508: 7b 2a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r2
   64510: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64518: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   64520: 7a 0a 00 fd 00 00 00 00      	stdw [r10 - 0x300], 0x0
   64528: 7a 0a 08 fd 00 00 00 00      	stdw [r10 - 0x2f8], 0x0
   64530: bf a8 00 00 00 00 00 00      	mov64 r8, r10
   64538: 07 08 00 00 d8 fe ff ff      	add64 r8, -0x128
   64540: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   64548: 07 02 00 00 e0 fc ff ff      	add64 r2, -0x320
   64550: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   64558: b7 03 00 00 30 00 00 00      	mov64 r3, 0x30
   64560: 85 10 00 00 bd 67 00 00      	call 0x67bd
   64568: 79 a1 28 f6 00 00 00 00      	ldxdw r1, [r10 - 0x9d8]
   64570: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64578: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   64580: 7b 2a 90 ff 00 00 00 00      	stxdw [r10 - 0x70], r2
   64588: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   64590: 7b 2a 88 ff 00 00 00 00      	stxdw [r10 - 0x78], r2
   64598: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   645a0: 7b 2a 80 ff 00 00 00 00      	stxdw [r10 - 0x80], r2
   645a8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   645b0: 7b 1a 78 ff 00 00 00 00      	stxdw [r10 - 0x88], r1
   645b8: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   645c0: 07 02 00 00 78 ff ff ff      	add64 r2, -0x88
   645c8: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   645d0: 85 10 00 00 03 53 ff ff      	call -0xacfd
   645d8: 15 00 1e 00 00 00 00 00      	jeq r0, 0x0, +0x1e <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1bf8>
   645e0: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   645e8: 07 01 00 00 38 f7 ff ff      	add64 r1, -0x8c8
   645f0: b7 02 00 00 f8 07 00 00      	mov64 r2, 0x7f8
   645f8: 85 10 00 00 4b 47 00 00      	call 0x474b
   64600: 79 a3 40 f7 00 00 00 00      	ldxdw r3, [r10 - 0x8c0]
   64608: 79 a2 38 f7 00 00 00 00      	ldxdw r2, [r10 - 0x8c8]
   64610: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64618: 07 01 00 00 28 f7 ff ff      	add64 r1, -0x8d8
   64620: 18 04 00 00 c4 b3 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9b3c4
   64630: b7 05 00 00 12 00 00 00      	mov64 r5, 0x12
   64638: 85 10 00 00 b0 3c ff ff      	call -0xc350
   64640: 79 a1 28 f7 00 00 00 00      	ldxdw r1, [r10 - 0x8d8]
   64648: 79 a2 30 f7 00 00 00 00      	ldxdw r2, [r10 - 0x8d0]
   64650: 05 00 4f fe 00 00 00 00      	ja -0x1b1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   64658: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64660: 07 01 00 00 28 f8 ff ff      	add64 r1, -0x7d8
   64668: b7 02 00 00 d5 07 00 00      	mov64 r2, 0x7d5
   64670: 85 10 00 00 3c 47 00 00      	call 0x473c
   64678: 79 a3 30 f8 00 00 00 00      	ldxdw r3, [r10 - 0x7d0]
   64680: 79 a2 28 f8 00 00 00 00      	ldxdw r2, [r10 - 0x7d8]
   64688: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64690: 07 01 00 00 18 f8 ff ff      	add64 r1, -0x7e8
   64698: 18 04 00 00 b8 b3 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9b3b8
   646a8: b7 05 00 00 0c 00 00 00      	mov64 r5, 0xc
   646b0: 85 10 00 00 a1 3c ff ff      	call -0xc35f
   646b8: 79 a1 18 f8 00 00 00 00      	ldxdw r1, [r10 - 0x7e8]
   646c0: 79 a2 20 f8 00 00 00 00      	ldxdw r2, [r10 - 0x7e0]
   646c8: 05 00 40 fe 00 00 00 00      	ja -0x1c0 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   646d0: 79 a1 78 f6 00 00 00 00      	ldxdw r1, [r10 - 0x988]
   646d8: 71 11 29 00 00 00 00 00      	ldxb r1, [r1 + 0x29]
   646e0: 15 01 56 00 00 00 00 00      	jeq r1, 0x0, +0x56 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1ec0>
   646e8: 79 a3 08 f9 00 00 00 00      	ldxdw r3, [r10 - 0x6f8]
   646f0: 72 0a d8 fe ff 00 00 00      	stb [r10 - 0x128], 0xff
   646f8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64700: 07 04 00 00 e0 fc ff ff      	add64 r4, -0x320
   64708: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   64710: 07 05 00 00 d8 fe ff ff      	add64 r5, -0x128
   64718: 18 01 00 00 68 f3 09 00 00 00 00 00 00 00 00 00      	lddw r1, 0x9f368
   64728: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   64730: 85 10 00 00 ff ff ff ff      	call -0x1
   64738: 55 00 1b 01 00 00 00 00      	jne r0, 0x0, +0x11b <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2540>
   64740: 79 a1 f8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x308]
   64748: 7b 1a b0 ff 00 00 00 00      	stxdw [r10 - 0x50], r1
   64750: 79 a1 f0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x310]
   64758: 7b 1a a8 ff 00 00 00 00      	stxdw [r10 - 0x58], r1
   64760: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   64768: 7b 1a a0 ff 00 00 00 00      	stxdw [r10 - 0x60], r1
   64770: 79 a1 e0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x320]
   64778: 7b 1a 98 ff 00 00 00 00      	stxdw [r10 - 0x68], r1
   64780: 71 a1 d8 fe 00 00 00 00      	ldxb r1, [r10 - 0x128]
   64788: 79 a2 80 f6 00 00 00 00      	ldxdw r2, [r10 - 0x980]
   64790: 73 12 00 00 00 00 00 00      	stxb [r2 + 0x0], r1
   64798: 79 a1 b8 f6 00 00 00 00      	ldxdw r1, [r10 - 0x948]
   647a0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   647a8: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   647b0: 7b 2a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r2
   647b8: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   647c0: 7b 2a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r2
   647c8: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   647d0: 7b 2a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r2
   647d8: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   647e0: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   647e8: 79 a2 98 ff 00 00 00 00      	ldxdw r2, [r10 - 0x68]
   647f0: 5d 21 0a 00 00 00 00 00      	jne r1, r2, +0xa <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1d70>
   647f8: 79 a1 a0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x60]
   64800: 79 a2 e8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x318]
   64808: 5d 12 07 00 00 00 00 00      	jne r2, r1, +0x7 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1d70>
   64810: 79 a1 a8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x58]
   64818: 79 a2 f0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x310]
   64820: 5d 12 04 00 00 00 00 00      	jne r2, r1, +0x4 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1d70>
   64828: b7 01 00 00 00 00 00 00      	mov64 r1, 0x0
   64830: 79 a2 b0 ff 00 00 00 00      	ldxdw r2, [r10 - 0x50]
   64838: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   64840: 1d 23 01 00 00 00 00 00      	jeq r3, r2, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1d78>
   64848: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   64850: 15 01 37 00 00 00 00 00      	jeq r1, 0x0, +0x37 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x1f38>
   64858: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64860: 07 01 00 00 e8 f7 ff ff      	add64 r1, -0x818
   64868: b7 02 00 00 d6 07 00 00      	mov64 r2, 0x7d6
   64870: 85 10 00 00 fc 46 00 00      	call 0x46fc
   64878: 79 a3 f0 f7 00 00 00 00      	ldxdw r3, [r10 - 0x810]
   64880: 79 a2 e8 f7 00 00 00 00      	ldxdw r2, [r10 - 0x818]
   64888: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64890: 07 01 00 00 d8 f7 ff ff      	add64 r1, -0x828
   64898: 18 04 00 00 54 b4 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9b454
   648a8: b7 05 00 00 0d 00 00 00      	mov64 r5, 0xd
   648b0: 85 10 00 00 61 3c ff ff      	call -0xc39f
   648b8: 79 a3 e0 f7 00 00 00 00      	ldxdw r3, [r10 - 0x820]
   648c0: 79 a2 d8 f7 00 00 00 00      	ldxdw r2, [r10 - 0x828]
   648c8: 79 a1 b8 f6 00 00 00 00      	ldxdw r1, [r10 - 0x948]
   648d0: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   648d8: 79 14 18 00 00 00 00 00      	ldxdw r4, [r1 + 0x18]
   648e0: 7b 4a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r4
   648e8: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   648f0: 7b 4a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r4
   648f8: 79 14 08 00 00 00 00 00      	ldxdw r4, [r1 + 0x8]
   64900: 7b 4a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r4
   64908: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64910: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   64918: 79 a1 98 ff 00 00 00 00      	ldxdw r1, [r10 - 0x68]
   64920: 7b 1a 00 fd 00 00 00 00      	stxdw [r10 - 0x300], r1
   64928: 79 a1 a0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x60]
   64930: 7b 1a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r1
   64938: 79 a1 a8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x58]
   64940: 7b 1a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r1
   64948: 79 a1 b0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x50]
   64950: 7b 1a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r1
   64958: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64960: 07 01 00 00 c8 f7 ff ff      	add64 r1, -0x838
   64968: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64970: 07 04 00 00 e0 fc ff ff      	add64 r4, -0x320
   64978: 85 10 00 00 42 41 00 00      	call 0x4142
   64980: 79 a1 c8 f7 00 00 00 00      	ldxdw r1, [r10 - 0x838]
   64988: 79 a2 d0 f7 00 00 00 00      	ldxdw r2, [r10 - 0x830]
   64990: 05 00 e7 fd 00 00 00 00      	ja -0x219 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   64998: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   649a0: 07 01 00 00 08 f8 ff ff      	add64 r1, -0x7f8
   649a8: b7 02 00 00 d0 07 00 00      	mov64 r2, 0x7d0
   649b0: 85 10 00 00 d4 46 00 00      	call 0x46d4
   649b8: 79 a3 10 f8 00 00 00 00      	ldxdw r3, [r10 - 0x7f0]
   649c0: 79 a2 08 f8 00 00 00 00      	ldxdw r2, [r10 - 0x7f8]
   649c8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   649d0: 07 01 00 00 f8 f7 ff ff      	add64 r1, -0x808
   649d8: 18 04 00 00 1e bb 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9bb1e
   649e8: b7 05 00 00 05 00 00 00      	mov64 r5, 0x5
   649f0: 85 10 00 00 39 3c ff ff      	call -0xc3c7
   649f8: 79 a1 f8 f7 00 00 00 00      	ldxdw r1, [r10 - 0x808]
   64a00: 79 a2 00 f8 00 00 00 00      	ldxdw r2, [r10 - 0x800]
   64a08: 05 00 d8 fd 00 00 00 00      	ja -0x228 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   64a10: 18 01 00 00 65 5d 2b b6 00 00 00 00 fd 6d 18 b0      	lddw r1, -0x4fe7920249d4a29b
   64a20: 7b 1a f0 fe 00 00 00 00      	stxdw [r10 - 0x110], r1
   64a28: 18 01 00 00 51 89 cb 97 00 00 00 00 f5 d2 ff 3b      	lddw r1, 0x3bffd2f597cb8951
   64a38: 7b 1a e8 fe 00 00 00 00      	stxdw [r10 - 0x118], r1
   64a40: 18 01 00 00 44 db 15 68 00 00 00 00 bf 17 5b aa      	lddw r1, -0x55a4e84097ea24bc
   64a50: 7b 1a e0 fe 00 00 00 00      	stxdw [r10 - 0x120], r1
   64a58: 18 01 00 00 01 56 e0 f6 00 00 00 00 93 66 5a cf      	lddw r1, -0x30a5996c091fa9ff
   64a68: 7b 1a d8 fe 00 00 00 00      	stxdw [r10 - 0x128], r1
   64a70: 72 0a b8 fe ff 00 00 00      	stb [r10 - 0x148], 0xff
   64a78: bf a3 00 00 00 00 00 00      	mov64 r3, r10
   64a80: 07 03 00 00 d8 fe ff ff      	add64 r3, -0x128
   64a88: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64a90: 07 04 00 00 e0 fc ff ff      	add64 r4, -0x320
   64a98: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   64aa0: 07 05 00 00 b8 fe ff ff      	add64 r5, -0x148
   64aa8: 18 01 00 00 f8 f3 09 00 00 00 00 00 00 00 00 00      	lddw r1, 0x9f3f8
   64ab8: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   64ac0: 85 10 00 00 ff ff ff ff      	call -0x1
   64ac8: 55 00 a9 00 00 00 00 00      	jne r0, 0x0, +0xa9 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2540>
   64ad0: 79 a1 f8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x308]
   64ad8: 7b 1a d0 ff 00 00 00 00      	stxdw [r10 - 0x30], r1
   64ae0: 79 a1 f0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x310]
   64ae8: 7b 1a c8 ff 00 00 00 00      	stxdw [r10 - 0x38], r1
   64af0: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   64af8: 7b 1a c0 ff 00 00 00 00      	stxdw [r10 - 0x40], r1
   64b00: 79 a1 e0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x320]
   64b08: 7b 1a b8 ff 00 00 00 00      	stxdw [r10 - 0x48], r1
   64b10: 71 a1 b8 fe 00 00 00 00      	ldxb r1, [r10 - 0x148]
   64b18: 79 a2 80 f6 00 00 00 00      	ldxdw r2, [r10 - 0x980]
   64b20: 73 12 01 00 00 00 00 00      	stxb [r2 + 0x1], r1
   64b28: 79 a1 a0 f6 00 00 00 00      	ldxdw r1, [r10 - 0x960]
   64b30: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64b38: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   64b40: 7b 2a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r2
   64b48: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   64b50: 7b 2a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r2
   64b58: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   64b60: 7b 2a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r2
   64b68: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64b70: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   64b78: 79 a2 b8 ff 00 00 00 00      	ldxdw r2, [r10 - 0x48]
   64b80: 5d 21 0a 00 00 00 00 00      	jne r1, r2, +0xa <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2100>
   64b88: 79 a1 c0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x40]
   64b90: 79 a2 e8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x318]
   64b98: 5d 12 07 00 00 00 00 00      	jne r2, r1, +0x7 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2100>
   64ba0: 79 a1 c8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x38]
   64ba8: 79 a2 f0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x310]
   64bb0: 5d 12 04 00 00 00 00 00      	jne r2, r1, +0x4 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2100>
   64bb8: b7 01 00 00 00 00 00 00      	mov64 r1, 0x0
   64bc0: 79 a2 d0 ff 00 00 00 00      	ldxdw r2, [r10 - 0x30]
   64bc8: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   64bd0: 1d 23 01 00 00 00 00 00      	jeq r3, r2, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2108>
   64bd8: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   64be0: 15 01 2d 00 00 00 00 00      	jeq r1, 0x0, +0x2d <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2278>
   64be8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64bf0: 07 01 00 00 b8 f7 ff ff      	add64 r1, -0x848
   64bf8: b7 02 00 00 d6 07 00 00      	mov64 r2, 0x7d6
   64c00: 85 10 00 00 8a 46 00 00      	call 0x468a
   64c08: 79 a3 c0 f7 00 00 00 00      	ldxdw r3, [r10 - 0x840]
   64c10: 79 a2 b8 f7 00 00 00 00      	ldxdw r2, [r10 - 0x848]
   64c18: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64c20: 07 01 00 00 a8 f7 ff ff      	add64 r1, -0x858
   64c28: 18 04 00 00 23 bb 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9bb23
   64c38: b7 05 00 00 0e 00 00 00      	mov64 r5, 0xe
   64c40: 85 10 00 00 ef 3b ff ff      	call -0xc411
   64c48: 79 a3 b0 f7 00 00 00 00      	ldxdw r3, [r10 - 0x850]
   64c50: 79 a2 a8 f7 00 00 00 00      	ldxdw r2, [r10 - 0x858]
   64c58: 79 a1 a0 f6 00 00 00 00      	ldxdw r1, [r10 - 0x960]
   64c60: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64c68: 79 14 18 00 00 00 00 00      	ldxdw r4, [r1 + 0x18]
   64c70: 7b 4a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r4
   64c78: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   64c80: 7b 4a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r4
   64c88: 79 14 08 00 00 00 00 00      	ldxdw r4, [r1 + 0x8]
   64c90: 7b 4a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r4
   64c98: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64ca0: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   64ca8: 79 a1 b8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x48]
   64cb0: 7b 1a 00 fd 00 00 00 00      	stxdw [r10 - 0x300], r1
   64cb8: 79 a1 c0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x40]
   64cc0: 7b 1a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r1
   64cc8: 79 a1 c8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x38]
   64cd0: 7b 1a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r1
   64cd8: 79 a1 d0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x30]
   64ce0: 7b 1a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r1
   64ce8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64cf0: 07 01 00 00 98 f7 ff ff      	add64 r1, -0x868
   64cf8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64d00: 07 04 00 00 e0 fc ff ff      	add64 r4, -0x320
   64d08: 85 10 00 00 d0 40 00 00      	call 0x40d0
   64d10: 79 a1 98 f7 00 00 00 00      	ldxdw r1, [r10 - 0x868]
   64d18: 79 a2 a0 f7 00 00 00 00      	ldxdw r2, [r10 - 0x860]
   64d20: 05 00 75 fd 00 00 00 00      	ja -0x28b <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   64d28: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   64d30: b7 02 00 00 0d 00 00 00      	mov64 r2, 0xd
   64d38: 18 03 00 00 10 eb 09 00 00 00 00 00 00 00 00 00      	lddw r3, 0x9eb10
   64d48: 85 10 00 00 00 59 00 00      	call 0x5900
   64d50: 79 a1 a0 f6 00 00 00 00      	ldxdw r1, [r10 - 0x960]
   64d58: 71 11 28 00 00 00 00 00      	ldxb r1, [r1 + 0x28]
   64d60: 15 01 62 00 00 00 00 00      	jeq r1, 0x0, +0x62 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x25a0>
   64d68: 79 a3 08 f9 00 00 00 00      	ldxdw r3, [r10 - 0x6f8]
   64d70: 72 0a d8 fe ff 00 00 00      	stb [r10 - 0x128], 0xff
   64d78: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64d80: 07 04 00 00 e0 fc ff ff      	add64 r4, -0x320
   64d88: bf a5 00 00 00 00 00 00      	mov64 r5, r10
   64d90: 07 05 00 00 d8 fe ff ff      	add64 r5, -0x128
   64d98: 18 01 00 00 30 f3 09 00 00 00 00 00 00 00 00 00      	lddw r1, 0x9f330
   64da8: b7 02 00 00 01 00 00 00      	mov64 r2, 0x1
   64db0: 85 10 00 00 ff ff ff ff      	call -0x1
   64db8: 55 00 4b 00 00 00 00 00      	jne r0, 0x0, +0x4b <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2540>
   64dc0: 79 a1 f8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x308]
   64dc8: 7b 1a f0 ff 00 00 00 00      	stxdw [r10 - 0x10], r1
   64dd0: 79 a1 f0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x310]
   64dd8: 7b 1a e8 ff 00 00 00 00      	stxdw [r10 - 0x18], r1
   64de0: 79 a1 e8 fc 00 00 00 00      	ldxdw r1, [r10 - 0x318]
   64de8: 7b 1a e0 ff 00 00 00 00      	stxdw [r10 - 0x20], r1
   64df0: 79 a1 e0 fc 00 00 00 00      	ldxdw r1, [r10 - 0x320]
   64df8: 7b 1a d8 ff 00 00 00 00      	stxdw [r10 - 0x28], r1
   64e00: 71 a1 d8 fe 00 00 00 00      	ldxb r1, [r10 - 0x128]
   64e08: 79 a2 80 f6 00 00 00 00      	ldxdw r2, [r10 - 0x980]
   64e10: 73 12 02 00 00 00 00 00      	stxb [r2 + 0x2], r1
   64e18: 79 a1 98 f6 00 00 00 00      	ldxdw r1, [r10 - 0x968]
   64e20: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64e28: 79 12 18 00 00 00 00 00      	ldxdw r2, [r1 + 0x18]
   64e30: 7b 2a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r2
   64e38: 79 12 10 00 00 00 00 00      	ldxdw r2, [r1 + 0x10]
   64e40: 7b 2a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r2
   64e48: 79 12 08 00 00 00 00 00      	ldxdw r2, [r1 + 0x8]
   64e50: 7b 2a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r2
   64e58: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64e60: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   64e68: 79 a2 d8 ff 00 00 00 00      	ldxdw r2, [r10 - 0x28]
   64e70: 5d 21 0a 00 00 00 00 00      	jne r1, r2, +0xa <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x23f0>
   64e78: 79 a1 e0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x20]
   64e80: 79 a2 e8 fc 00 00 00 00      	ldxdw r2, [r10 - 0x318]
   64e88: 5d 12 07 00 00 00 00 00      	jne r2, r1, +0x7 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x23f0>
   64e90: 79 a1 e8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x18]
   64e98: 79 a2 f0 fc 00 00 00 00      	ldxdw r2, [r10 - 0x310]
   64ea0: 5d 12 04 00 00 00 00 00      	jne r2, r1, +0x4 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x23f0>
   64ea8: b7 01 00 00 00 00 00 00      	mov64 r1, 0x0
   64eb0: 79 a2 f0 ff 00 00 00 00      	ldxdw r2, [r10 - 0x10]
   64eb8: 79 a3 f8 fc 00 00 00 00      	ldxdw r3, [r10 - 0x308]
   64ec0: 1d 23 01 00 00 00 00 00      	jeq r3, r2, +0x1 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x23f8>
   64ec8: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   64ed0: 15 01 4d 00 00 00 00 00      	jeq r1, 0x0, +0x4d <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x2668>
   64ed8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64ee0: 07 01 00 00 68 f7 ff ff      	add64 r1, -0x898
   64ee8: b7 02 00 00 d6 07 00 00      	mov64 r2, 0x7d6
   64ef0: 85 10 00 00 2c 46 00 00      	call 0x462c
   64ef8: 79 a3 70 f7 00 00 00 00      	ldxdw r3, [r10 - 0x890]
   64f00: 79 a2 68 f7 00 00 00 00      	ldxdw r2, [r10 - 0x898]
   64f08: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64f10: 07 01 00 00 58 f7 ff ff      	add64 r1, -0x8a8
   64f18: 18 04 00 00 d6 b3 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9b3d6
   64f28: b7 05 00 00 09 00 00 00      	mov64 r5, 0x9
   64f30: 85 10 00 00 91 3b ff ff      	call -0xc46f
   64f38: 79 a3 60 f7 00 00 00 00      	ldxdw r3, [r10 - 0x8a0]
   64f40: 79 a2 58 f7 00 00 00 00      	ldxdw r2, [r10 - 0x8a8]
   64f48: 79 a1 98 f6 00 00 00 00      	ldxdw r1, [r10 - 0x968]
   64f50: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64f58: 79 14 18 00 00 00 00 00      	ldxdw r4, [r1 + 0x18]
   64f60: 7b 4a f8 fc 00 00 00 00      	stxdw [r10 - 0x308], r4
   64f68: 79 14 10 00 00 00 00 00      	ldxdw r4, [r1 + 0x10]
   64f70: 7b 4a f0 fc 00 00 00 00      	stxdw [r10 - 0x310], r4
   64f78: 79 14 08 00 00 00 00 00      	ldxdw r4, [r1 + 0x8]
   64f80: 7b 4a e8 fc 00 00 00 00      	stxdw [r10 - 0x318], r4
   64f88: 79 11 00 00 00 00 00 00      	ldxdw r1, [r1 + 0x0]
   64f90: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   64f98: 79 a1 d8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x28]
   64fa0: 7b 1a 00 fd 00 00 00 00      	stxdw [r10 - 0x300], r1
   64fa8: 79 a1 e0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x20]
   64fb0: 7b 1a 08 fd 00 00 00 00      	stxdw [r10 - 0x2f8], r1
   64fb8: 79 a1 e8 ff 00 00 00 00      	ldxdw r1, [r10 - 0x18]
   64fc0: 7b 1a 10 fd 00 00 00 00      	stxdw [r10 - 0x2f0], r1
   64fc8: 79 a1 f0 ff 00 00 00 00      	ldxdw r1, [r10 - 0x10]
   64fd0: 7b 1a 18 fd 00 00 00 00      	stxdw [r10 - 0x2e8], r1
   64fd8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   64fe0: 07 01 00 00 48 f7 ff ff      	add64 r1, -0x8b8
   64fe8: bf a4 00 00 00 00 00 00      	mov64 r4, r10
   64ff0: 07 04 00 00 e0 fc ff ff      	add64 r4, -0x320
   64ff8: 85 10 00 00 72 40 00 00      	call 0x4072
   65000: 79 a1 48 f7 00 00 00 00      	ldxdw r1, [r10 - 0x8b8]
   65008: 79 a2 50 f7 00 00 00 00      	ldxdw r2, [r10 - 0x8b0]
   65010: 05 00 17 fd 00 00 00 00      	ja -0x2e9 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   65018: 18 01 00 00 a8 e9 09 00 00 00 00 00 00 00 00 00      	lddw r1, 0x9e9a8
   65028: 7b 1a e0 fc 00 00 00 00      	stxdw [r10 - 0x320], r1
   65030: 7a 0a 00 fd 00 00 00 00      	stdw [r10 - 0x300], 0x0
   65038: 7a 0a e8 fc 01 00 00 00      	stdw [r10 - 0x318], 0x1
   65040: 7a 0a f8 fc 00 00 00 00      	stdw [r10 - 0x308], 0x0
   65048: 7a 0a f0 fc 08 00 00 00      	stdw [r10 - 0x310], 0x8
   65050: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   65058: 07 01 00 00 e0 fc ff ff      	add64 r1, -0x320
   65060: 18 02 00 00 b8 e9 09 00 00 00 00 00 00 00 00 00      	lddw r2, 0x9e9b8
   65070: 85 10 00 00 b5 5a 00 00      	call 0x5ab5
   65078: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   65080: 07 01 00 00 88 f7 ff ff      	add64 r1, -0x878
   65088: b7 02 00 00 d2 07 00 00      	mov64 r2, 0x7d2
   65090: 85 10 00 00 f8 45 00 00      	call 0x45f8
   65098: 79 a3 90 f7 00 00 00 00      	ldxdw r3, [r10 - 0x870]
   650a0: 79 a2 88 f7 00 00 00 00      	ldxdw r2, [r10 - 0x878]
   650a8: bf a1 00 00 00 00 00 00      	mov64 r1, r10
   650b0: 07 01 00 00 78 f7 ff ff      	add64 r1, -0x888
   650b8: 18 04 00 00 23 bb 09 00 00 00 00 00 00 00 00 00      	lddw r4, 0x9bb23
   650c8: b7 05 00 00 0e 00 00 00      	mov64 r5, 0xe
   650d0: 85 10 00 00 5d 3b ff ff      	call -0xc4a3
   650d8: 79 a1 78 f7 00 00 00 00      	ldxdw r1, [r10 - 0x888]
   650e0: 79 a2 80 f7 00 00 00 00      	ldxdw r2, [r10 - 0x880]
   650e8: 05 00 fc fc 00 00 00 00      	ja -0x304 <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0xdf8>
   650f0: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   650f8: b7 02 00 00 09 00 00 00      	mov64 r2, 0x9
   65100: 18 03 00 00 10 eb 09 00 00 00 00 00 00 00 00 00      	lddw r3, 0x9eb10
   65110: 85 10 00 00 87 58 00 00      	call 0x5887
   65118: b7 01 00 00 01 00 00 00      	mov64 r1, 0x1
   65120: b7 02 00 00 0e 00 00 00      	mov64 r2, 0xe
   65128: 18 03 00 00 10 eb 09 00 00 00 00 00 00 00 00 00      	lddw r3, 0x9eb10
   65138: 85 10 00 00 82 58 00 00      	call 0x5882
   65140: 79 a8 c0 f6 00 00 00 00      	ldxdw r8, [r10 - 0x940]
   65148: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   65150: 07 01 00 00 d8 01 00 00      	add64 r1, 0x1d8
   65158: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   65160: 07 02 00 00 28 fa ff ff      	add64 r2, -0x5d8
   65168: b7 03 00 00 ed 00 00 00      	mov64 r3, 0xed
   65170: 85 10 00 00 3b 66 00 00      	call 0x663b
   65178: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   65180: 07 01 00 00 18 00 00 00      	add64 r1, 0x18
   65188: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   65190: 07 02 00 00 40 fc ff ff      	add64 r2, -0x3c0
   65198: b7 03 00 00 40 00 00 00      	mov64 r3, 0x40
   651a0: 85 10 00 00 35 66 00 00      	call 0x6635
   651a8: 79 a1 20 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3e0]
   651b0: 7b 18 60 00 00 00 00 00      	stxdw [r8 + 0x60], r1
   651b8: 79 a1 28 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d8]
   651c0: 7b 18 68 00 00 00 00 00      	stxdw [r8 + 0x68], r1
   651c8: 79 a1 30 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3d0]
   651d0: 7b 18 70 00 00 00 00 00      	stxdw [r8 + 0x70], r1
   651d8: 79 a1 38 fc 00 00 00 00      	ldxdw r1, [r10 - 0x3c8]
   651e0: 7b 18 78 00 00 00 00 00      	stxdw [r8 + 0x78], r1
   651e8: 79 a1 70 fe 00 00 00 00      	ldxdw r1, [r10 - 0x190]
   651f0: 7b 18 98 00 00 00 00 00      	stxdw [r8 + 0x98], r1
   651f8: 79 a1 68 fe 00 00 00 00      	ldxdw r1, [r10 - 0x198]
   65200: 7b 18 90 00 00 00 00 00      	stxdw [r8 + 0x90], r1
   65208: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   65210: 07 01 00 00 a8 00 00 00      	add64 r1, 0xa8
   65218: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   65220: 07 02 00 00 e0 fd ff ff      	add64 r2, -0x220
   65228: b7 03 00 00 88 00 00 00      	mov64 r3, 0x88
   65230: 85 10 00 00 23 66 00 00      	call 0x6623
   65238: 79 a1 b8 fd 00 00 00 00      	ldxdw r1, [r10 - 0x248]
   65240: 7b 18 34 01 00 00 00 00      	stxdw [r8 + 0x134], r1
   65248: 79 a1 c0 fd 00 00 00 00      	ldxdw r1, [r10 - 0x240]
   65250: 7b 18 3c 01 00 00 00 00      	stxdw [r8 + 0x13c], r1
   65258: 79 a1 c8 fd 00 00 00 00      	ldxdw r1, [r10 - 0x238]
   65260: 7b 18 44 01 00 00 00 00      	stxdw [r8 + 0x144], r1
   65268: 79 a1 d0 fd 00 00 00 00      	ldxdw r1, [r10 - 0x230]
   65270: 7b 18 4c 01 00 00 00 00      	stxdw [r8 + 0x14c], r1
   65278: 61 a1 d8 fd 00 00 00 00      	ldxw r1, [r10 - 0x228]
   65280: 63 18 54 01 00 00 00 00      	stxw [r8 + 0x154], r1
   65288: bf 81 00 00 00 00 00 00      	mov64 r1, r8
   65290: 07 01 00 00 68 01 00 00      	add64 r1, 0x168
   65298: bf a2 00 00 00 00 00 00      	mov64 r2, r10
   652a0: 07 02 00 00 18 ff ff ff      	add64 r2, -0xe8
   652a8: b7 03 00 00 59 00 00 00      	mov64 r3, 0x59
   652b0: 85 10 00 00 13 66 00 00      	call 0x6613
   652b8: 69 a1 14 ff 00 00 00 00      	ldxh r1, [r10 - 0xec]
   652c0: 61 a2 10 ff 00 00 00 00      	ldxw r2, [r10 - 0xf0]
   652c8: 79 a3 58 f6 00 00 00 00      	ldxdw r3, [r10 - 0x9a8]
   652d0: 63 38 00 00 00 00 00 00      	stxw [r8 + 0x0], r3
   652d8: 79 a3 90 f6 00 00 00 00      	ldxdw r3, [r10 - 0x970]
   652e0: 63 38 04 00 00 00 00 00      	stxw [r8 + 0x4], r3
   652e8: 79 a3 38 f6 00 00 00 00      	ldxdw r3, [r10 - 0x9c8]
   652f0: 63 38 30 01 00 00 00 00      	stxw [r8 + 0x130], r3
   652f8: 73 78 c1 01 00 00 00 00      	stxb [r8 + 0x1c1], r7
   65300: 79 a3 b0 f6 00 00 00 00      	ldxdw r3, [r10 - 0x950]
   65308: 73 38 c5 02 00 00 00 00      	stxb [r8 + 0x2c5], r3
   65310: 79 a3 a8 f6 00 00 00 00      	ldxdw r3, [r10 - 0x958]
   65318: 6b 38 c6 02 00 00 00 00      	stxh [r8 + 0x2c6], r3
   65320: 79 a3 20 f6 00 00 00 00      	ldxdw r3, [r10 - 0x9e0]
   65328: 7b 38 f0 02 00 00 00 00      	stxdw [r8 + 0x2f0], r3
   65330: 79 a3 50 f6 00 00 00 00      	ldxdw r3, [r10 - 0x9b0]
   65338: 7b 38 e8 02 00 00 00 00      	stxdw [r8 + 0x2e8], r3
   65340: 79 a3 88 f6 00 00 00 00      	ldxdw r3, [r10 - 0x978]
   65348: 7b 38 e0 02 00 00 00 00      	stxdw [r8 + 0x2e0], r3
   65350: 79 a3 98 f6 00 00 00 00      	ldxdw r3, [r10 - 0x968]
   65358: 7b 38 d8 02 00 00 00 00      	stxdw [r8 + 0x2d8], r3
   65360: 79 a3 a0 f6 00 00 00 00      	ldxdw r3, [r10 - 0x960]
   65368: 7b 38 d0 02 00 00 00 00      	stxdw [r8 + 0x2d0], r3
   65370: 79 a3 78 f6 00 00 00 00      	ldxdw r3, [r10 - 0x988]
   65378: 7b 38 c8 02 00 00 00 00      	stxdw [r8 + 0x2c8], r3
   65380: 79 a3 70 f6 00 00 00 00      	ldxdw r3, [r10 - 0x990]
   65388: 7b 38 d0 01 00 00 00 00      	stxdw [r8 + 0x1d0], r3
   65390: 79 a3 b8 f6 00 00 00 00      	ldxdw r3, [r10 - 0x948]
   65398: 7b 38 c8 01 00 00 00 00      	stxdw [r8 + 0x1c8], r3
   653a0: 79 a3 30 f6 00 00 00 00      	ldxdw r3, [r10 - 0x9d0]
   653a8: 7b 38 60 01 00 00 00 00      	stxdw [r8 + 0x160], r3
   653b0: 7b 68 58 01 00 00 00 00      	stxdw [r8 + 0x158], r6
   653b8: 79 a3 28 f6 00 00 00 00      	ldxdw r3, [r10 - 0x9d8]
   653c0: 7b 38 a0 00 00 00 00 00      	stxdw [r8 + 0xa0], r3
   653c8: 79 a3 40 f6 00 00 00 00      	ldxdw r3, [r10 - 0x9c0]
   653d0: 7b 38 88 00 00 00 00 00      	stxdw [r8 + 0x88], r3
   653d8: 79 a3 48 f6 00 00 00 00      	ldxdw r3, [r10 - 0x9b8]
   653e0: 7b 38 80 00 00 00 00 00      	stxdw [r8 + 0x80], r3
   653e8: 7b 98 58 00 00 00 00 00      	stxdw [r8 + 0x58], r9
   653f0: 79 a3 60 f6 00 00 00 00      	ldxdw r3, [r10 - 0x9a0]
   653f8: 7b 38 10 00 00 00 00 00      	stxdw [r8 + 0x10], r3
   65400: 79 a3 68 f6 00 00 00 00      	ldxdw r3, [r10 - 0x998]
   65408: 7b 38 08 00 00 00 00 00      	stxdw [r8 + 0x8], r3
   65410: 63 28 c2 01 00 00 00 00      	stxw [r8 + 0x1c2], r2
   65418: 6b 18 c6 01 00 00 00 00      	stxh [r8 + 0x1c6], r1
   65420: 05 00 45 fb 00 00 00 00      	ja -0x4bb <_ZN133_$LT$mayhem_recovered..InitializeMayhemState$u20$as$u20$anchor_lang..Accounts$LT$mayhem_recovered..InitializeMayhemStateBumps$GT$$GT$12try_accounts17h93595efcd4153f6cE+0x378>
